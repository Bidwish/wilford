<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_otp = trim($_POST['otp']);
    $stored_otp = $_SESSION['otp'] ?? null;
    $phone = $_SESSION['phone'] ?? null;

    if ($stored_otp && $user_otp == $stored_otp) {
        $success = "OTP verified successfully for $phone!";
        session_destroy(); // Clear session after verification
    } else {
        $error = "Invalid OTP. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Verify OTP</title>
  <style>
    body { font-family: Arial; background: #f8f8f8; padding: 30px; }
    form { background: #fff; padding: 20px; border-radius: 8px; max-width: 400px; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    input, button { width: 100%; padding: 10px; margin: 8px 0; }
    button { background: #28a745; color: #fff; border: none; cursor: pointer; }
    button:hover { background: #218838; }
  </style>
</head>
<body>

<h2>Verify OTP</h2>

<form method="POST">
  <label>Enter OTP Code:</label><br>
  <input type="text" name="otp" required placeholder="Enter OTP"><br>
  <button type="submit">Verify OTP</button>
</form>

<?php if (!empty($success)): ?>
  <p style="color:green;"><?= htmlspecialchars($success) ?></p>
<?php elseif (!empty($error)): ?>
  <p style="color:red;"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

</body>
</html>