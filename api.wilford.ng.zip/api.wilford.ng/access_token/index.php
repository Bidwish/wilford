<?php
//include '../config/database.php';

function checkLastUpdate($con, $recordId) {
  // Fetch the last updated timestamp
  $stmt = mysqli_prepare($con, "SELECT reset_time FROM api_keys WHERE id = ?");
  mysqli_stmt_bind_param($stmt, "i", $recordId);
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  $row = mysqli_fetch_assoc($result);
    
  // Check Time 
  date_default_timezone_set('Africa/Lagos');
  $givenTime = $row['reset_time'];
  $givenTime = strtotime($givenTime);
  $currentTime = time();

  $diff = $currentTime - $givenTime;
  // 1200 seconds = 20 minutes
  if ($diff >= 1200) {
    // Fetch API keys securely
    $clientId = fetchApiKey($con, 6);
    $accountId = fetchApiKey($con, 7);
    $clientSecret = fetchApiKey($con, 9);
    getNombaAccessToken($clientId, $clientSecret, $accountId);
    // Run the code if 20 minutes have passed
    // echo "✅ 20 minutes have passed";
  } else {
    // Wait or do something else
    // echo "❌ 20 minutes have not passed yet";
  }
}

// Get a new access token from Nomba
function getNombaAccessToken($clientId, $clientSecret, $accountId) {
  global $con;

  $url = 'https://api.nomba.com/v1/auth/token/issue';

  $data = [
    "grant_type" => "client_credentials",
    "client_id" => $clientId,
    "client_secret" => $clientSecret
  ];

  $headers = [
    'Content-Type: application/json',
    'accountId: ' . $accountId
  ];

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification for local testing
  curl_setopt($ch, CURLOPT_VERBOSE, true); // Enable debugging output

  $response = curl_exec($ch);
  $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
  if (curl_errno($ch)) {
    // die("❌ cURL Error: " . curl_error($ch));
  }

  curl_close($ch);

  if ($httpCode == 200) {
    $responseData = json_decode($response, true);

    if (isset($responseData['data']['access_token'])) {
      // New Access Token
      $newAccessToken = $responseData['data']['access_token'];
      // Time Reset
      $date = new DateTime('now', new DateTimeZone('Africa/Lagos'));
      $timeSet = $date->format('Y-m-d H:i:s');

      // Update access token in the database
      $stmt = mysqli_prepare($con, "UPDATE api_keys SET `key` = ?, `reset_time` = ? WHERE id = 8");
      mysqli_stmt_bind_param($stmt, "ss", $newAccessToken, $timeSet);
      mysqli_stmt_execute($stmt);
      mysqli_stmt_close($stmt);

      // echo "✅ Access token updated successfully.<br>";
    }  else {
      // echo "⚠️ API Response Error: Missing access_token field.<br>";
    }
  } else {
    // echo "❌ Failed to get access token. HTTP Code: $httpCode <br>";
    // echo "Response: " . $response . "<br>";
  }
}

$recordId = 8; // Replace with your actual record ID
checkLastUpdate($con, $recordId);
?>