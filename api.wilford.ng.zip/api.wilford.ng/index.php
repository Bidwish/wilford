<?php

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => "https://api.nomba.com/v1/transfers/bank",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "{\n  \"amount\": 50,\n  \"accountNumber\": \"2150917476\",\n  \"accountName\": \"Ezemba Emmanuel Onyedikachi\",\n  \"bankCode\": \"033\",\n  \"merchantTxRef\": \"UNQWF_123abxnksksjjwjwkskwkjsjsjsh\",\n  \"senderName\": \"Bidwish Emmanuel\",\n  \"narration\": \"Testing Payment\"\n}",
  CURLOPT_HTTPHEADER => [
    "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJHOjc0MmJiMDExLTQ5MTAtNGJmMy04YTY4LTY5NzFhMmM3YzlkNSI6Ikc6NzQyYmIwMTEtNDkxMC00YmYzLThhNjgtNjk3MWEyYzdjOWQ1IiwiUjpWRU5ET1JfQVBJX0FETUlOIjoiUjpWRU5ET1JfQVBJX0FETUlOIiwiaWF0IjoxNzQzMTYxNTYwLCJzdWIiOiIyY2IzMTIxNC05YmVkLTRjMjMtOTA2OC1iNDgzMjY1ODFjMjYiLCJleHAiOjE3NDMxNjMzNjB9.YRvHc2SAAlQo84n8q96xzWS3fznm6C2kzoLUYIsjkvU",
    "Content-Type: application/json",
    "accountId: 742bb011-4910-4bf3-8a68-6971a2c7c9d5"
  ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}

?>