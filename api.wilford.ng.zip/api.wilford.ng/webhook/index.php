<?php
include '../config/database.php';
include '../fcm/index.php';

// === LOGGING ===
$logFile = "webhook_log.txt";
file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);

// === RAW INPUT ===
$rawData = file_get_contents("php://input");
file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);
$data = json_decode($rawData, true);

if (!$data || !isset($data['event_type'])) {
    http_response_code(400);
    echo json_encode(['status' => false, 'message' => 'Invalid webhook payload']);
    exit;
}

// === EXTRACT BASIC DATA ===
$eventType   = strtolower(trim($data['event_type']));
$requestId   = $data['requestId'] ?? null;
$transaction = $data['data']['transaction'] ?? [];
$customer    = $data['data']['customer'] ?? [];
$merchant    = $data['data']['merchant'] ?? [];

$merchantTxRef = $transaction['merchantTxRef'] ?? null;
$transactionId = $transaction['transactionId'] ?? null;
$sessionId     = $transaction['sessionId'] ?? null;

$amount     = $transaction['transactionAmount'] ?? 0;
$fee        = $transaction['fee'] ?? 0;
$bankCode   = $customer['bankCode'] ?? '';
$bankName   = $customer['bankName'] ?? '';
$senderName = $customer['senderName'] ?? '';
$recipientName = $customer['recipientName'] ?? ($transaction['aliasAccountName'] ?? '');
$accountNumber = $customer['accountNumber'] ?? ($transaction['aliasAccountNumber'] ?? '');

file_put_contents($logFile, "Parsed Event: $eventType | TxRef: $merchantTxRef | TxId: $transactionId | Amount: $amount\n", FILE_APPEND);

// === HANDLE EVENTS ===

// --------------------
// Deposit (payment_success)
// --------------------
if ($eventType === 'payment_success') {

    // Find linked user by virtual account number
    $stmt = $con->prepare("SELECT user_id FROM nomba_bank_account WHERE accountNumber = ?");
    $stmt->bind_param("s", $transaction['aliasAccountNumber']);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $userId = $user['user_id'];

        // Update user balance
        $con->query("UPDATE users SET bala = bala + {$amount} WHERE id = {$userId}");
        
        // Get FCM Token
        $fcm = $con->prepare("SELECT fcm_token FROM users WHERE id = ?");
        $fcm->bind_param("i", $userId);
        $fcm->execute();
        $fcmResult = $fcm->get_result();
        $fcmToken = $fcmResult->fetch_assoc();

        // Record deposit if not already logged
        $check = $con->prepare("SELECT id FROM payments WHERE requestId = ?");
        $check->bind_param("s", $requestId);
        $check->execute();
        $exists = $check->get_result()->num_rows > 0;
        $check->close();

        if (!$exists) {
            $stmt = $con->prepare("INSERT INTO payments (payment_id, user_id, rec_id, amount, method, status, transactionId, senderAccNumber, senderAccName, senderBank, recAccNumber, recAccName, requestId, created_at, recCode, recBank, senderCode)
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?)");
            $payment_id = generate21DigitNumber();
            $method = '0';
            $status = 'successful';
            $recBank = 'Wilford';
            $recCode = '0000';
            $senderCode = $customer['bankCode'] ?? '';
  $stmt->bind_param("siiissssssssssss", $payment_id, $userId, $userId, $amount, $method, $status, $transactionId, $customer['accountNumber'], $customer['senderName'], $bankName, $transaction['aliasAccountNumber'], $transaction['aliasAccountName'], $requestId, $recCode, $recBank, $senderCode);
            $stmt->execute();
            $stmt->close();

            file_put_contents($logFile, "Deposit recorded for user_id=$userId amount=$amount\n", FILE_APPEND);
            
            // Save notification 
            notification($con,$payment_id,$userId,$customer['senderName'],$amount,$now);
            
            // Send FCM notification
            sendFCM(
                'Incoming Transfer Successful',
                "{$customer['senderName']} has sent you ₦{$amount}. Get 6% bonus on Wilford Airtime and Data.",
                $fcmToken['fcm_token']
            );


        }
    } else {
        file_put_contents($logFile, "No linked user found for account: {$transaction['aliasAccountNumber']}\n", FILE_APPEND);
    }
}

// --------------------
// Payout Success (outgoing transfer completed)
// --------------------
elseif ($eventType === 'payout_success') {
    $ref = $merchantTxRef ?? $transactionId;

    // Update payment status to successful
   $stmt = $con->prepare("UPDATE payments SET status = 'successful', updated_at = NOW() WHERE transactionId = ?");
    $stmt->bind_param("s", $ref);
    $stmt->execute();
    $stmt->close();

    $affected = mysqli_stmt_affected_rows($stmt);
    if ($affected > 0) {
      file_put_contents($logFile, "Payout marked successful: $ref\n", FILE_APPEND);
    } else {
      file_put_contents($logFile, "No payment record found for payout_success ref: $ref\n", FILE_APPEND);
    }
}

// --------------------
// Payout Refund (money bounced back to you)
// --------------------
elseif ($eventType === 'payout_refund') {
    $ref = $merchantTxRef ?? $transactionId;

    // Find payment and refund the user
    $stmt = $con->prepare("SELECT user_id, amount FROM payments WHERE transactionId = ?");
    $stmt->bind_param("s", $ref);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($result) {
        $user_id = $result['user_id'];
        $amount  = $result['amount'];

        // Refund the user
        $stmt = $con->prepare("UPDATE users SET bala = bala + ? WHERE id = ?");
        $stmt->bind_param("di", $amount, $user_id);
        $stmt->execute();
        $stmt->close();

        // Update payment status
        $stmt = $con->prepare("UPDATE payments SET status = 'reverse', updated_at = NOW() WHERE transactionId = ?");
        $stmt->bind_param("s", $ref);
        $stmt->execute();
        $stmt->close();

        file_put_contents($logFile, "Refund processed for user $user_id | ref: $ref | amount: $amount\n", FILE_APPEND);
    } else {
        file_put_contents($logFile, "Refund event received but record not found for ref: $ref\n", FILE_APPEND);
    }
}

// --------------------
// Payment Failed (e.g. card purchase failed)
// --------------------
elseif ($eventType === 'payment_failed') {
    file_put_contents($logFile, "Payment failed event: $transactionId\n", FILE_APPEND);
}

// --------------------
// Anything else
// --------------------
else {
    file_put_contents($logFile, "Unhandled event type: $eventType\n", FILE_APPEND);
}

http_response_code(200);
echo json_encode(['status' => true, 'message' => 'Webhook processed successfully']);
?>