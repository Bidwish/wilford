<?php
$servername = "localhost";
$username = "fhphuoyj_wilford";
$password = "bidwish25744517";
$database = "fhphuoyj_wilford";
$con = mysqli_connect($servername,$username,$password,$database);
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// Fetch API key securely
function fetchApiKey($con, $id) {
  $stmt = mysqli_prepare($con, "SELECT `key` FROM api_keys WHERE id = ?");
  mysqli_stmt_bind_param($stmt, "i", $id);
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  $row = mysqli_fetch_assoc($result);   
  if (!$row) {
    return null;
  }
  return $row['key'];
}

// Get SMTP
$smtp = "SELECT email, password, host, name, api_email FROM smtp";
$smtp_run = mysqli_query($con, $smtp);
$smtpData = mysqli_fetch_assoc($smtp_run);
$host = $smtpData['host'];
$s_email = $smtpData['email'];
$a_email = $smtpData['api_email'];
$cname = $smtpData['name'];
$password = $smtpData['password'];

// Insert Notification 
function notification($con, $payment_id,$user_id,$senderName,$amount,$created_at) {
  $stmt = mysqli_prepare($con, "INSERT INTO notifications (payment_id, user_id, senderName, amount, status, created_at) VALUES (?, ?, ?, ?, ?, ?)");
  $status = "2";
  mysqli_stmt_bind_param($stmt, "iisiis", $payment_id, $user_id, $senderName, $amount, $status, $created_at);
  mysqli_stmt_execute($stmt);
}

// admin commission 
function adminCommission($con, $commission) {
    $id = 1;
    // fetch commission balance 
    $stmt = mysqli_prepare($con, "SELECT bala FROM admin WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $adminData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    $bala = $adminData['bala'];
    
    $newBala = $bala + $commission;
    // update commission 
    $stmt = mysqli_prepare($con, "UPDATE admin SET bala = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $newBala, $id);
    mysqli_stmt_execute($stmt);
}

// Get time & date
function getNigeriaDateTime($format = 'Y-m-d H:i:s') {
    date_default_timezone_set('Africa/Lagos');
    return date($format);
}
$now = getNigeriaDateTime();

// Genrate payment Id
function generate21DigitNumber() {
    $min = '100000000000000000000';
    $max = '999999999999999999999';

    $random = bcadd(bcmul(bcsub($max, $min), bcdiv(mt_rand(0, mt_getrandmax()), mt_getrandmax(), 20)), $min);
    return $random;
}

?> 