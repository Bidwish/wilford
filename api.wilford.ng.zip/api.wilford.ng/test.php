<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone']);

    // Generate a random 4-digit OTP
    $otp = rand(1000, 9999);

    // Store OTP and phone number in session (for testing)
    $_SESSION['otp'] = $otp;
    $_SESSION['phone'] = $phone;

    // KudiSMS API endpoint
    $url = "https://my.kudisms.net/api/otp";

    // Prepare data
    $data = [
        "token"        => "6cKbSrHqVLdDxme94XM5JYga0FtEI3sGoB7nufvjZWUy8TzOhCk1iwpNPARQ2l",
        "senderID"     => "Wilford VTU",       // Approved Sender ID
        "recipients"   => $phone,                 // E.g. 234703XXXXXXX
        "otp"          => $otp,
        "appnamecode"  => "4862309889",    // Approved App Name Code
        "templatecode" => "4512991398"    // Approved Template Code
    ];

    // Send request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);

    if (isset($result['status']) && $result['status'] === 'success') {
        // Redirect to verify page
        header("Location: verify.php");
        exit;
    } else {
        $error = $result['msg'] ?? 'Failed to send OTP';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Send OTP | Registration</title>
  <style>
    body { font-family: Arial; background: #f8f8f8; padding: 30px; }
    form { background: #fff; padding: 20px; border-radius: 8px; max-width: 400px; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    input, button { width: 100%; padding: 10px; margin: 8px 0; }
    button { background: #007bff; color: #fff; border: none; cursor: pointer; }
    button:hover { background: #0056b3; }
  </style>
</head>
<body>

<h2>User Registration (Send OTP)</h2>

<form method="POST">
  <label>Enter Phone Number (e.g. 234703XXXXXXX):</label><br>
  <input type="text" name="phone" required placeholder="234703XXXXXXX"><br>
  <button type="submit">Send OTP</button>
</form>

<?php if (!empty($error)): ?>
  <p style="color:red;"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

</body>
</html>