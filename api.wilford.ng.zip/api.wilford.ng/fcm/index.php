<?php

function sendFCM($title, $body, $deviceToken) {
    $serviceAccountFile = __DIR__ . '/wilford-23e1d-191c8ed0b1df.json'; 

    // Notification data
    $image = '';
    $ref   = 'extra-data';

    $serviceAccount = json_decode(file_get_contents($serviceAccountFile), true);
    if (!$serviceAccount) {
        die("Failed to load service account file.\n");
    }

    $clientEmail = $serviceAccount['client_email'];
    $privateKey  = $serviceAccount['private_key'];
    $tokenUri    = $serviceAccount['token_uri'];
    $projectId = $serviceAccount['project_id'];

    $header = ['alg' => 'RS256', 'typ' => 'JWT'];
    $now = time();
    $claimSet = [
        'iss' => $clientEmail,
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud' => $tokenUri,
        'iat' => $now,
        'exp' => $now + 3600,
    ];

    function base64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    $jwtHeader = base64url_encode(json_encode($header));
    $jwtClaim = base64url_encode(json_encode($claimSet));
    $jwtUnsigned = "$jwtHeader.$jwtClaim";

    openssl_sign($jwtUnsigned, $signature, $privateKey, 'SHA256');
    $jwtSignature = base64url_encode($signature);
    $jwt = "$jwtUnsigned.$jwtSignature";

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $tokenUri,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_POSTFIELDS => http_build_query([
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt,
        ]),
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        die('cURL Error (token): ' . curl_error($ch));
    }
    curl_close($ch);

    $tokenData = json_decode($response, true);
    if (empty($tokenData['access_token'])) {
        die("Failed to obtain access token:\n$response\n");
    }

    $accessToken = $tokenData['access_token'];

    // $deviceToken = 'fMbt_X2tQVCKKn2Y9bWrK6:APA91bGMQC4kT6Cjw-HTcxKJ6k7xBxjxu3gL46w9Uda-OkVtt2mu5plllOBv7A5JaLXw8x-nXyiArMGvuNbJGSd7fOxcutrN55qSafqdu4SGZJJAToS7Q2s';

    $fcmUrl = "https://fcm.googleapis.com/v1/projects/$projectId/messages:send";

    $message = [
        "message" => [
            "token" => $deviceToken,
            "notification" => [     
                "title" => $title,
                "body"  => $body,
                "image" => $image
            ],
            "data" => [            
                "extra" => $ref
            ]
        ]
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $fcmUrl,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer $accessToken",
            "Content-Type: application/json; charset=UTF-8"
        ],
        CURLOPT_POSTFIELDS => json_encode($message),
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        die('cURL Error (send): ' . curl_error($ch));
    }
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    echo "Response Code: $httpCode\n";
    echo "Response Body: $response\n";

}

?>