<?php
include('../../../config/database.php');
header('Content-Type: application/json');

    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    // $logFile = "webhook_log.txt";
    // file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    // file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);
    
    
    // API endpoint for verification
    $endpoint = 'https://vtpass.com/api/merchant-verify';
    
    // API key
    $secret_key = fetchApiKey($con, 4);
    $api_key = fetchApiKey($con, 3);
        
    $provider = $data['provider'] ?? '';
    $smartcardNumber = $data['smartcard'] ?? '';
    
    if (empty($provider) || empty($smartcardNumber)) {
        http_response_code(402);
        echo json_encode([
            'status' => 'error',
            'message' => 'Enter your SmartCard number and select your provider.'
        ]);
    }
    
    // Data to be sent in the POST request
    $postData = [
        'serviceID' => $provider,
        'billersCode' => $smartcardNumber
    ];
    
    // Set up cURL
    $ch = curl_init($endpoint);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'api-key: ' . $api_key,
        'secret-key: ' . $secret_key
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    // Execute cURL request
    $response = curl_exec($ch);
    
    if ($response === false) {
        echo 'Curl error: ' . curl_error($ch);
    } else {
        $response_data = json_decode($response, true);
    
        if ($response_data !== null)     {
            $check = $response_data['content']['Customer_Name'] ?? '';
            
            if($response_data['code'] === "000" && !empty($check)) {
                http_response_code(200);
                echo json_encode([
                    'status' => 'success',
                    'customer' => $response_data['content']['Customer_Name']
                ]);
            } else {
                http_response_code(402);
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Invalid SmartCard number.'
                ]);
            }
        } else {
            http_response_code(401);
            echo json_encode([
                'status' => 'error',
                'message' => 'System busy. Please try again later.'
            ]);
        }
    }
    // Close cURL session
    curl_close($ch); 
?>