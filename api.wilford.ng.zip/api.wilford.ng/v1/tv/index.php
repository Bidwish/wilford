<?php
include('../../config/database.php');
include './../headers/post_with_auth.php'; // must contain CORS headers properly

date_default_timezone_set('Africa/Lagos'); // Set the timezone to Africa/Lagos (GMT +1)

// Endpoint URL
$url = 'https://vtpass.com/api/pay';

// Get the Secret Key from the database 
$secret_key = fetchApiKey($con, 4);
$api_key = fetchApiKey($con, 3);

$requestId = null;

$today = date('Ymd'); // Get today's date in YYYYMMDD format
$hourMinute = date('Hi'); // Get the current hour and minute in HHII format
$randomPart = substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyz'), 0, 12); // Generate a random alphanumeric string of length 12

// Generate the Request ID if not provided
if ($requestId === null) {
  $requestId = $today . $hourMinute . $randomPart;
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    // $logFile = "webhook_log.txt";
    // file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    // file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);
   
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
      
    $amount = $data['amount'];
    $amoun = $data['amount'].'00';
    $provider = $data['provider'];
    $uic = $data['uic'];
    $planName = $data['plan_name'];
    $code = $data['code'];
    $phone = $data['phone'];
    $name = $data['customer_name'];
    $method = '6';
    $user_id = $data['user_id'];
    $pin = $data['pin']; 
    
    if ($provider == 'dstv' || $provider == 'gotv' || $provider == 'showmax') {
        $commission = ($amount / 100) * 1.5;       
    }  elseif ($provider == 'startimes') {
        $commission = ($amount / 100) * 2;
    } else {
        $commission = 0;
    }
    
    // Verify Pin
    $pin_query = "SELECT * FROM pin WHERE user_id = ?";
    $stmt = mysqli_prepare($con, $pin_query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $pin_run = mysqli_stmt_get_result($stmt);

    if ($pin_run && mysqli_num_rows($pin_run) > 0) {
        $pinData = mysqli_fetch_assoc($pin_run);
        $hashedPin = $pinData['code'];

        if (password_verify($pin, $hashedPin)) {
            // Fetch user balance
            $stmt = mysqli_prepare($con, "SELECT bala FROM users WHERE id = ? AND token = ?");
            mysqli_stmt_bind_param($stmt, "is", $user_id, $token);
            mysqli_stmt_execute($stmt);
            $userData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            $bala = $userData['bala'];

            if ($bala >= $amount) {
                // Update balances
                $new_sender_balance = $bala - $amount;                
                $stmt = mysqli_prepare($con, "UPDATE users SET bala = ? WHERE id = ?");
                mysqli_stmt_bind_param($stmt, "ii", $new_sender_balance, $user_id);
                mysqli_stmt_execute($stmt);
            
                if (mysqli_stmt_affected_rows($stmt) > 0) {
                    $data = array(
                        'request_id' => $requestId, // Generate a unique request ID
                        'serviceID' => $provider,
                        'billersCode' => $uic,
                        'amount' => $amoun,
                        'variation_code' => $code,
                        'phone' => $phone,
                        'quantity' => '1',
                        'subscription_type' => 'change'
                    );
        
                    // Initialize cURL session
                    $ch = curl_init();

                    // Set request headers
                    $headers = array(
                        "api-key: $api_key",
                        "secret-key: $secret_key"
                    );
          
                    // Set cURL options
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
          
                    // Execute cURL request
                    $response = curl_exec($ch);
          
                    if ($response === false) {
                        //echo 'Curl error: ' . curl_error($ch);
                    } else {
                        // Decode the response if it's JSON, for example
                        $response_data = json_decode($response, true);
                        $transactionId = $response_data['content']['transactions']['transactionId'] ?? '';
                        $code = $response_data['code'];
                        if($code == 000){
                            $status = "successful";
                            cableRecode ($transactionId, $user_id, $method, $status, $amount, $phone, $pts, $name, $uic, $provider, $planName, $con, $commission, $now);
                            // update commission 
                            adminCommission($con, $commission);
                            $_SESSION['success'] = "The recipient account is expected to be credited within 5 minutes.";
                            http_response_code(200);
                            echo json_encode([
                                'code' => '200',
                                'status' => false,
                                'message' => 'Successful sent.'
                            ]);
                        } else {
                            // Store the failed details in the database 
                            $status = "failed";
                            $transactionId = generate21DigitNumber();
                            cableRecode ($transactionId, $user_id, $method, $status, $amount, $phone, $pts, $name, $uic, $provider, $planName, $con, $commission, $now);
            
                            // Refound the user 
                            $new_balance = $bala;                
                            $stmt = mysqli_prepare($con, "UPDATE users SET bala = ? WHERE id = ?");
                            mysqli_stmt_bind_param($stmt, "ii", $new_balance, $user_id);
                            mysqli_stmt_execute($stmt);
                            $_SESSION['error'] = "Transaction Failed";
                            
                            
                            http_response_code(500); // User creation failed
                            echo json_encode(['code' => '500', 'status' => false, 'message' => 'Payment Failed, Please try again']);
                            exit();
                        }
                    }
                    // Close cURL session
                    curl_close($ch);

                    return $response;                   
                } else {                   
                    http_response_code(500); // User creation failed
                    echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
                    exit();
                }
            } else {
                http_response_code(402);
                echo json_encode([
                    'code' => '402',
                    'status' => false,
                    'message' => 'Insufficient Balance, Please found your account and try again.'
                ]); 
            }
        } else {
            http_response_code(401);
            echo json_encode([
                'code' => '401',
                'status' => false,
                'message' => 'Incorrect Pin, Please try again.'
            ]);
            exit();
        }
    } else {
        http_response_code(400);
        echo json_encode([
            'code' => '400',
            'status' => false,
            'message' => 'Please Set your transaction Pin to proceed.'
        ]);
        exit();
    } 
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

Function cableRecode ($transactionId, $user_id, $method, $status, $amount, $phone, $pts, $name, $uic, $provider, $planName, $con, $commission, $now) {
     
    $stmt = mysqli_prepare($con, "INSERT INTO payments (payment_id, transactionId, user_id, method, status, amount, phone, serial, pts, accName, mtNumber, provider, pin, adminCommission, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $payment_id = generate21DigitNumber();
    mysqli_stmt_bind_param($stmt, "iiiisiisssissss", $payment_id, $transactionId, $user_id, $method, $status, $amount, $phone, $planName, $pts, $name, $uic, $provider, $planName, $commission, $now);
    mysqli_stmt_execute($stmt);
}

?>