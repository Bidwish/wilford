<?php
include('../../../config/database.php');
header('Content-Type: application/json');

// Assume $con is already initialized (mysqli connection)
$dataPlans = [];

$get = "SELECT * FROM tv";
$get_run = mysqli_query($con, $get);

if ($get_run) {
    while ($plan = mysqli_fetch_assoc($get_run)) {
        $dataPlans[] = [
            'name' => $plan['name'],
            'amount' => $plan['amount'],
            'validity' => $plan['code'],
            'provider' => $plan['provider'],                    
        ];
    }

    $response = [
        'success' => true,
        'data' => $dataPlans
    ];
} else {
    $response = [
        'success' => false,
        'message' => 'Failed to fetch data plans'
    ];
}

echo json_encode($response);
?>