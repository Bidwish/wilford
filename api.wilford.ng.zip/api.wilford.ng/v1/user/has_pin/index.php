<?php
include('../../../config/database.php');
include '../../headers/get.php'; // Set CORS and JSON headers

// --- Check if Authorization header exists ---
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (!$authHeader) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authorization header missing.']);
    exit;
}

// --- Extract Bearer token ---
list($type, $token) = explode(' ', $authHeader, 2);
if (strcasecmp($type, 'Bearer') !== 0 || empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid token format.']);
    exit;
}

// --- Find user by token ---
$stmt = $con->prepare("SELECT id FROM users WHERE token = ?");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token.']);
    exit;
}

$user = $result->fetch_assoc();
$userId = $user['id'];

// --- Check if user has a PIN ---
$stmt = $con->prepare("SELECT code FROM pin WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$pinResult = $stmt->get_result();

$hasPin = false;
if ($pinResult->num_rows > 0) {
    $pinData = $pinResult->fetch_assoc();
    $hasPin = !empty($pinData['code']);
}

// --- Return JSON response ---
http_response_code(200);
echo json_encode([
    'success' => true,
    'has_pin' => true,
]);
exit;
?>
