<?php
include('../../../config/database.php');
include '../../headers/get.php'; // (Set correct CORS headers for GET requests)
include '../../../access_token/index.php';


function generateRandom10DigitNumber() {
    return mt_rand(1000000000, 9999999999);
}

// API keys
$accessToken = fetchApiKey($con, 8);
$accountId = fetchApiKey($con, 7);
$clientId = fetchApiKey($con, 6);
$clientSecret = fetchApiKey($con, 9);

// Check request method
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = $authHeader;
    $data = $authHeader;

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }

    // Lookup user by token (assuming token is email or any saved token)
    $stmt = $con->prepare("SELECT id FROM users WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
        $id = $userData['id'];
        
        if ($id) {
            // Check if the user already has a virtual account
            $stmt = mysqli_prepare($con, "SELECT accountName, accountNumber, bankName FROM nomba_bank_account WHERE user_id = ?");
            mysqli_stmt_bind_param($stmt, "s", $id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) > 0) {
                while ($data = mysqli_fetch_assoc($result)) {
                    displayBankDetails($data['accountName'], $data['accountNumber'], $data['bankName']);
                }
            } else {
                // No account found, create one
                $randomNumber = generateRandom10DigitNumber();
                createVirtualAccount($accessToken, $accountId, $id, $randomNumber);
            }
        } else { 
            echo "Invalid session or missing user data.";
        } 
    } else {
        http_response_code(404);
        echo json_encode([
            'status' => false,
            'message' => 'Account not found.'
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
}

// Display Bank Details
function displayBankDetails($accName, $accNumber, $bankName) { 
    http_response_code(200);
    echo json_encode([
        'status' => true,
        'accountName' => $accName,
        'accountNumber' => $accNumber,
        'bankName' => $bankName
    ]);
}

// Create Virtual Account
function createVirtualAccount($accessToken, $accountId, $id, $randomNumber) {
    global $con;

    // Get user details for account name
    $stmt = $con->prepare("SELECT fname, lname FROM users WHERE id = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $stmt->bind_result($fname, $lname);
    $stmt->fetch();
    $stmt->close();

    $name = $fname . ' ' . $lname;

    $url = 'https://api.nomba.com/v1/accounts/virtual';

    $data = [
        "accountRef" => "user_" . $randomNumber,
        "accountName" => $name
    ];

    $headers = [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
        'accountId: ' . $accountId
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    // Optional: Disable SSL verification (for testing only)
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo "cURL Error: " . curl_error($ch);
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200) { // 201 Created
        $responseData = json_decode($response, true);
        $accNumber = $responseData['data']['bankAccountNumber'];
        $accName = $responseData['data']['bankAccountName'];
        $bankName = $responseData['data']['bankName'];
        $ref = $responseData['data']['accountRef']; 
        
        // Save account to DB with error debugging
        $stmt = mysqli_prepare($con, "INSERT INTO nomba_bank_account (user_id, accountName, accountNumber, bankName, ref) VALUES (?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sssss", $id, $accName, $accNumber, $bankName, $ref);

        if (mysqli_stmt_execute($stmt)) {
            displayBankDetails($accName, $accNumber, $bankName);
        } else {
            echo "Error inserting data: " . mysqli_stmt_error($stmt);
        }
        mysqli_stmt_close($stmt);
    } else {
        $responseData = json_decode($response, true);
        if ($responseData['code'] == 00) {
            $accNumber = $responseData['data']['bankAccountNumber'];
            $accName = $responseData['data']['bankAccountName'];
            $bankName = $responseData['data']['bankName'];
            $ref = $responseData['data']['accountRef']; 
        
            // Save account to DB with error debugging
            $stmt = mysqli_prepare($con, "INSERT INTO nomba_bank_account (user_id, accountName, accountNumber, bankName, ref) VALUES (?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "sssss", $id, $accName, $accNumber, $bankName, $ref);
  
            if (mysqli_stmt_execute($stmt)) {
                displayBankDetails($accName, $accNumber, $bankName);
            } else {
                echo "Error inserting data: " . mysqli_stmt_error($stmt);
            }
            mysqli_stmt_close($stmt);
        }
    }
    
}

?>