<?php
include('../../../config/database.php');
include '../../headers/post_with_auth.php'; // Sets CORS and JSON headers

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (!$authHeader) {
    http_response_code(401);
    echo json_encode(['status' => false, 'message' => 'Authorization header missing.']);
    exit;
}

list($type, $token) = explode(' ', $authHeader, 2);
if (strcasecmp($type, 'Bearer') !== 0 || empty($token)) {
    http_response_code(401);
    echo json_encode(['status' => false, 'message' => 'Invalid token format.']);
    exit;
}

$stmt = $con->prepare("SELECT id FROM users WHERE token = ?");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(401);
    echo json_encode(['status' => false, 'message' => 'Invalid or expired token.']);
    exit;
}

$user = $result->fetch_assoc();
$userId = $user['id'];

if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['status' => false, 'message' => 'No image uploaded or upload error.']);
    exit;
}

// Save to a permanent folder using a fixed filename
$uploadDir = '../../../../image.wilford.ng/profile/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$tmpPath = $_FILES['avatar']['tmp_name'];
$ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
$filename = "user_" . $userId . "." . $ext;
$destination = $uploadDir . $filename;

// Optionally delete any old file with different extension
$existingFiles = glob($uploadDir . "user_" . $userId . ".*");
foreach ($existingFiles as $file) {
    if (basename($file) !== $filename) {
        unlink($file);
    }
}

// Move uploaded file
if (!move_uploaded_file($tmpPath, $destination)) {
    http_response_code(500);
    echo json_encode(['status' => false, 'message' => 'Failed to move uploaded file.']);
    exit;
}

// Update user record with filename
$update = $con->prepare("UPDATE users SET profile = ? WHERE id = ?");
$update->bind_param("si", $filename, $userId);
$update->execute();

http_response_code(200);
echo json_encode([
    'status' => true,
    'message' => 'Profile image updated successfully.',
    'filename' => $filename,
    'url' => 'https://image.wilford.ng/profile/' . $filename
]);
?>
