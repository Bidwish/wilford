<?php
include('../../../config/database.php');
include '../../headers/post_with_auth.php'; // must contain CORS headers properly

function isUpTo18YearsBack($date) {
  $eighteenYearsAgo = strtotime('-18 years');
  $inputDate = strtotime($date);
  
  if ($inputDate <= $eighteenYearsAgo) {
    return true;
  } else {
    return false;
  }
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    $gender = $data['gender'];
    $dob = $data['dob'];
    
    if(empty($dob) || empty($gender)) {
        echo 400;
        exit;
    }
    
    if (isUpTo18YearsBack($dob)) {
        $add = "UPDATE users SET gender='$gender', dob='$dob', tier='1' WHERE token='$token'";
        $add_run = mysqli_query($con, $add);
    
        if($add_run) {
            http_response_code(200); // Success
            echo json_encode([
                'status' => true,
                'message' => 'Account Upgraeded Successfully!'
            ]);
            exit();
        } else {
            http_response_code(500); // 500 Method Not Allowed
            echo json_encode([
                'status' => false,
                'message' => 'Something went worng.'
            ]);
            exit();
        }
    }
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}


?>