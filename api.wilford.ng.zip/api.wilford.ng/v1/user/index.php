<?php
include('../../config/database.php');
include '../headers/get.php'; // (Set correct CORS headers for GET requests)

// Check request method
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = $authHeader;
    $data = $authHeader;

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }

    // Lookup user by token (assuming token is email or any saved token)
    $stmt = $con->prepare("SELECT * FROM users WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $account = $result->fetch_assoc();
        
        // Format phone correctly
        $formattedPhone = $account['phone'];
            if (substr($formattedPhone, 0, 1) !== '0') {
            $formattedPhone = '0' . $formattedPhone;
        }

        http_response_code(200);
        echo json_encode([
            'status' => true,
            'user' => [
                'id' => strval($account['id']),
                'fName' => $account['fname'],
                'mName' => $account['uname'],
                'lName' => $account['lname'],
                'email' => $account['email'],
                'bala' => strval($account['bala']),
                'dob' => $account['dob'],
                'gender' => $account['gender'],
                'phone' => $formattedPhone,
                'profile' => 'https://image.wilford.ng/profile/' . $account['profile'],
                'referral' => $account['referral'],
                'tier' => strval($account['tier']),
                'username' => $account['username']
            ]
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            'status' => false,
            'message' => 'Account not found.'
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
}
?>