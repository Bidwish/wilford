<?php
include('../../../config/database.php');
include '../../headers/post_with_auth.php'; // must contain CORS headers properly

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    // $logFile = "webhook_log.txt";
    // file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    // file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }

    $redeem = $data['code'];
    $userId = $data['user_id'];
    $fee = '100';
    
    // Check if the gift card code exists
    $stmt = $con->prepare("SELECT status, amount FROM giftcard WHERE code = ?");
    $stmt->bind_param("s", $redeem);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $status = $row['status'];
        $amount = $row['amount'] - '100';

        if ($status === "active") {
            // Update the user balance
            $updateBalance = $con->prepare("UPDATE users SET bala = bala + ? WHERE token = ? AND id = ?");
            $updateBalance->bind_param("isi", $amount, $token, $userId);
            
            if ($updateBalance->execute()) {
                // Mark the gift card as redeemed
                $updateGiftcard = $con->prepare("UPDATE giftcard SET status = 'redeemed' WHERE code = ?");
                $updateGiftcard->bind_param("s", $redeem);
                $updateGiftcard->execute();
                // Save to database 
                $method = "10";
                $status = "successful";
                $payment_id = generate21DigitNumber();
                $transactionId = rand(100000, 999999) . rand(100000, 999999);
                $fee = "100";
                // update commission 
                adminCommission($con, $fee); 
                $stmt = mysqli_prepare($con, "INSERT INTO payments (payment_id, transactionId, user_id, method, status, amount, fee, remark, created_at, adminCommission) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "iiiisiisss", $payment_id, $transactionId, $userId, $method, $status, $amount, $fee, $redeem, $now, $fee);
                mysqli_stmt_execute($stmt);
                
                http_response_code(200);
                echo json_encode([
                    'code' => '200',
                    'status' => true,
                    'message' => 'You have successfully redeem Your Gift Card.'
                ]);
            } else {
                http_response_code(500); // User creation failed
                echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
            }
        } else {
            http_response_code(401);
            echo json_encode([
                'code' => '401',
                'status' => false,
                'message' => 'Invalid or already redeemed gift card.'
            ]);
        }
    } else {
        http_response_code(401);
        echo json_encode([
            'code' => '401',
            'status' => false,
            'message' => 'Invalid or already redeemed gift card.'
        ]);
    }
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>