<?php
include('./../../config/database.php');
include './../headers/post_with_auth.php'; // must contain CORS headers properly

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    $pin = $data['pin'];
    $user_id = $data['user_id'];
    $email = $data['email'];
    $name = $data['sender_name'];
    $amount = $data['amount'];
    $message = $data['message'];
    
    $fee = '10';
    $total = $amount + $fee;
    
    // $userQuery = "SELECT id FROM users WHERE token = '$token'";
    // $userResult = mysqli_query($con, $userQuery);
    // $userData = mysqli_fetch_assoc($userResult);
    // $user_id = $userData['id'];
    
    // Verify the PIN
    $pin_query = "SELECT code FROM pin WHERE user_id = ?";
    $stmt = mysqli_prepare($con, $pin_query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $pin_run = mysqli_stmt_get_result($stmt);

    if ($pin_run && mysqli_num_rows($pin_run) > 0) {
        $pinData = mysqli_fetch_assoc($pin_run);
        $hashedPin = $pinData['code'];

        // Check if the PIN matches
        if (password_verify($pin, $hashedPin)) {
            // Fetch user balance
            
            $stmt = mysqli_prepare($con, "SELECT bala FROM users WHERE token = ?");
            mysqli_stmt_bind_param($stmt, "s", $token);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $userData = mysqli_fetch_assoc($result);

            if ($userData) {
                $bala = $userData['bala'];

                // Check if the user has enough balance
                if ($bala >= $total) {
                    // Deduct the amount
                    $new_sender_balance = $bala - $total;
                    $stmt = mysqli_prepare($con, "UPDATE users SET bala = ? WHERE id = ?");
                    mysqli_stmt_bind_param($stmt, "ii", $new_sender_balance, $user_id);
                    mysqli_stmt_execute($stmt);

                    if (mysqli_stmt_affected_rows($stmt) > 0) {
                        require "./../../Mail/phpmailer/PHPMailerAutoload.php";
                        $mail = new PHPMailer;

                        // SMTP configuration
                        $mail->isSMTP();
                        $mail->Host = $host;
                        $mail->Port = 587;
                        $mail->SMTPAuth = true;
                        $mail->SMTPSecure = 'tls';

                        $mail->Username = $a_email;
                        $mail->Password = $password;

                        $mail->setFrom($s_email, $cname);
                        $mail->addAddress($email);

                        // Generate a gift card code
                        $giftCardCode = strtoupper(bin2hex(random_bytes(10)));
                        $giftCard = implode('-', str_split($giftCardCode, 4));

                        // Email content
                        $mail->isHTML(true);
                        $mail->Subject = "Wilford Gift Card";
                        $mail->Body = '
                            <!DOCTYPE html>
                            <html lang="en">
                                <head>
                                    <meta charset="UTF-8">
                                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                                    <title>Gift Card Email</title>
                                    <style>
                                        body {
                                            font-family: Arial, sans-serif;
                                            margin: 0;
                                            padding: 0;
                                            background-color: #f9f9f9;
                                        }
                                        .email-container {
                                            max-width: 600px;
                                            margin: 20px auto;
                                            padding: 20px;
                                            background-color: #ffffff;
                                            border-radius: 8px;
                                            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                                        }
                                        .header {
                                            background-color: #4CAF50;
                                            color: #ffffff;
                                            text-align: center;
                                            padding: 10px 0;
                                            border-radius: 8px 8px 0 0;
                                        }
                                        .content {
                                            padding: 20px;
                                        }
                                        .gift-card {
                                            text-align: center;
                                            padding: 20px;
                                            border: 2px dashed #4CAF50;
                                            border-radius: 8px;
                                            background-color: #f3fff3;
                                        }
                                        .btn {
                                            display: inline-block;
                                            padding: 10px 20px;
                                            font-size: 18px;
                                            color: #ffffff;
                                            background-color: #4CAF50;
                                            text-decoration: none;
                                            border-radius: 5px;
                                        }
                                    </style>
                                </head>
                                <body>
                                    <div class="email-container">
                                        <div class="header">
                                            <h1>🎁 Your Gift Card Has Arrived!</h1>
                                        </div>
                                        <div class="content">
                                            <p>Hi <strong>' . htmlspecialchars($name) . '</strong>,</p>
                                            <p>You’ve received a gift card!</p>
                                            <div class="gift-card">
                                                <h2>Gift Card Details</h2>
                                                <p><strong>Amount:</strong> ₦' . number_format($amount, 2) . '</p>
                                               <p><strong>Message:</strong> ' . htmlspecialchars($message) . '</p>
                                                <p><strong>Card Code:</strong> ' . htmlspecialchars($giftCard) . '</p>
                                            </div>
                                        </div>
                                    </div>
                                </body>
                            </html>';

                        if ($mail->send()) {
                            $status = "successful";
                            $method = '9';
                            // update commission 
                            adminCommission($con, $fee); 
                            saveGiftCard($con, $user_id, $message, $amount, $email, $giftCard);
                            saveTransaction($con, $user_id, $method, $status, $amount, $name, $email, $fee, $now);
                            $_SESSION['success'] = 'Gift card to begin sent to the recipient email';
                            http_response_code(200);
                            echo json_encode([
                                'code' => '200',
                                'status' => false,
                                'message' => 'Successful sent.'
                            ]); 
                        } else {
                            refundUserBalance($con, $bala, $user_id);
                            http_response_code(500); // User creation failed
                            echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
                        }
                    } else {
                        http_response_code(500); // User creation failed
                        echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
                    }
                } else {
                    http_response_code(402);
                        echo json_encode([
                        'code' => '402',
                        'status' => false,
                        'message' => 'Insufficient Balance, Please found your account and try again.'
                    ]);                
                }
            } else {
                http_response_code(500); // User creation failed
                echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
                exit();
            }
        } else {
            http_response_code(401);
                echo json_encode([
                'code' => '401',
                'status' => false,
                'message' => 'Incorrect Pin, Please try again.'
            ]);
        }
    } else {      
        http_response_code(400);
        echo json_encode([
            'code' => '400',
            'status' => false,
            'message' => 'Please Set your transaction Pin to proceed.'
        ]);
    }
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

// Save transaction
function saveTransaction($con, $user_id, $method, $status, $amount, $name, $email, $fee, $now) {
    
    $stmt = mysqli_prepare($con, "INSERT INTO payments (payment_id, transactionId, user_id, method, status, amount, remark, email, fee, created_at, adminCommission) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $payment_id = generate21DigitNumber();
    $transactionId = generate21DigitNumber();;
    mysqli_stmt_bind_param($stmt, "iiiisississ", $payment_id, $transactionId, $user_id, $method, $status, $amount, $name, $email, $fee, $now, $fee);
    mysqli_stmt_execute($stmt);
}

// Save gift card
function saveGiftCard($con, $user_id, $message, $amount, $email, $giftCard) {
    $status = 'active';
    $stmt = mysqli_prepare($con, "INSERT INTO giftcard (user_id, message, amount, email, code, status) VALUES (?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "isisss", $user_id, $message, $amount, $email, $giftCard, $status);
    mysqli_stmt_execute($stmt);
}

// Refund balance
function refundUserBalance($con, $bala, $user_id) {
    $stmt = mysqli_prepare($con, "UPDATE users SET bala = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $bala, $user_id);
    mysqli_stmt_execute($stmt);
}

?>