<?php
include('../../../config/database.php');

function generateToken($length = 64) {
  $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  $token = '';
  for ($i = 0; $i < $length; $i++) {
    $token .= $characters[rand(0, strlen($characters) - 1)];
  }
  return $token;
}
$token = generateToken();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    include '../../headers/post.php';

    // Get the raw input just once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log raw input for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    $email = $data['email']; 

    $forgotten_query = "SELECT * FROM users WHERE email = '$email' ";
    $forgotten_run = mysqli_query($con, $forgotten_query);
    
    if (mysqli_num_rows($forgotten_run) > 0) {
      $update = "UPDATE token SET status='1' WHERE email = '$email' ";
      $update_run = mysqli_query($con, $update);
      $token_ = "INSERT INTO token (email,token,status) VALUES ('$email','$token', 0)";
      $token_run = mysqli_query($con, $token_);
      if($token_run) {
        require "../../../Mail/phpmailer/PHPMailerAutoload.php";
        $mail = new PHPMailer;
    
        $mail->isSMTP();
        $mail->Host=$host;
        $mail->Port=587;
        $mail->SMTPAuth=true;
        $mail->SMTPSecure='tls';
    
        $mail->Username=$a_email;
        $mail->Password=$password;
    
        $mail->setFrom($s_email, $cname);
        $mail->addAddress($email);
    
        $mail->isHTML(true);
        $mail->Subject="Reset Password";
        $mail->Body='
        <div style="font-family: Arial, sans-serif; width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
          <p style="color: #666; margin-bottom: 40px;">Dear user</h3>
          <p style="color: #666; margin-bottom: 20px;">You are trying to reset the password link with your account.</p>
          <p style="color: #666; margin-bottom: 20px;">To confirm your request, please use the button below:</p>
 
            <a href="https://'.$cname.'.ng/auth/reset/index.php?token='.$token.'">Reset Password</a>
          <p style="color: #666; margin-top: 20; margin-bottom: 40px;">The verification link will be valid for 30 minutes. Please do not share your link with anyone.</p>
          <h6><i style="color: #666; margin-bottom: 5px;">'.$cname.' Team<i></h6>
          <h6><i style="color: #666; margin-bottom: 10px;">Automated message. Please do not reply</i></h6>
        </div>';  
        if(!$mail->send()) {                                    
          echo "500"; 
        } else { 
          http_response_code(200);
          echo json_encode(['code' => '200', 'status' => false, 'message' => 'Forget Password Email successfully sent!']);    
        }	
      } else {
        http_response_code(500);
        echo json_encode(['code' => '500', 'status' => false, 'message' => 'Unknown error occurred, Please try again']);
      }
    } else {
      http_response_code(400);
      echo json_encode(['code' => '400', 'status' => false, 'message' => 'Invalid email address, Please try again']);
    }  
} else {
    http_response_code(500);
    echo json_encode(['status' => false, 'message' => 'Invalid request']);
    exit();
}

?>