<?php
include('../../../config/database.php');
include '../../headers/post.php'; // Contains proper CORS headers

// Generate a random token
function generateToken($length = 64) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $token = '';
    for ($i = 0; $i < $length; $i++) {
        $token .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $token;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Debug logging (optional)
    file_put_contents("webhook_log.txt", "Login hit: " . date("Y-m-d H:i:s") . "\nData: " . $rawData . "\n", FILE_APPEND);

    $phone = trim($data['phone'] ?? '');
    $password = trim($data['password'] ?? '');

    // Basic validation
    if (empty($phone) || empty($password)) {
        http_response_code(400);
        echo json_encode([
            'status' => false,
            'message' => 'Phone and password are required.'
        ]);
        exit;
    }

    // Look up the user
    $stmt = $con->prepare("SELECT * FROM users WHERE phone = ?");
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
        $userPasswordHash = $userData['password'];

        if (password_verify($password, $userPasswordHash)) {
            if ((int)$userData['status'] === 0) {
                http_response_code(402);
                echo json_encode([
                    'code' => '402',
                    'status' => false,
                    'message' => 'Your account is not yet verified. Please verify your phone.'
                ]);
                exit;
            }

            // Generate and store token
            $token = generateToken();
            $updateStmt = $con->prepare("UPDATE users SET token = ? WHERE id = ?");
            $updateStmt->bind_param("si", $token, $userData['id']);
            $updateStmt->execute();

            // Format phone correctly
            $formattedPhone = $userData['phone'];
            if (substr($formattedPhone, 0, 1) !== '0') {
                $formattedPhone = '0' . $formattedPhone;
            }

            // Build response
            http_response_code(200);
            echo json_encode([
                'code' => '200',
                'status' => true,
                'token' => $token,
                'user' => [
                    'id' => strval($userData['id']),
                    'fName' => $userData['fname'],
                    'mName' => $userData['uname'],
                    'lName' => $userData['lname'],
                    'email' => $userData['email'],
                    'bala' => strval($userData['bala']),
                    'dob' => $userData['dob'],
                    'gender' => $userData['gender'],
                    'phone' => $formattedPhone,
                    'profile' => 'https://image.wilford.ng/profile/' . $userData['profile'],
                    'referral' => $userData['referral'],
                    'tier' => strval($userData['tier']),
                    'username' => $userData['username']
                ]
            ]);
        } else {
            http_response_code(401);
            echo json_encode([
                'code' => '401',
                'status' => false,
                'message' => 'Invalid password.'
            ]);
        }
    } else {
        http_response_code(401);
        echo json_encode([
            'code' => '401',
            'status' => false,
            'message' => 'Invalid credentials.'
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
}
?>
