<?php
include('../../../../config/database.php');
include '../../../headers/post_with_auth.php'; // must contain CORS headers properly

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    $current = $data['cPin'];
    $code = $data['gCode'];
    $email = $data['email'];
    $pin = $data['nPin'];
    $c_pin = $data['rPin'];
    
    if ($pin !== $c_pin) {
        http_response_code(400);
        echo json_encode([
            'code' => '400',
            'status' => false,
            'message' => 'Your new pin do not match, Please try again.'
        ]);
        exit();
    }
    
    // Validate token
    $reset_query = "SELECT * FROM token WHERE token = '$code' AND email='$email' ";
    $reset_run = mysqli_query($con, $reset_query);

    if ($reset_run && mysqli_num_rows($reset_run) > 0) {
        $tokenData = mysqli_fetch_array($reset_run);
    
        // Check if user email exists
        $get_email = "SELECT * FROM users WHERE token = '$token' AND email = '$email'";
        $get_email_run = mysqli_query($con, $get_email);

        if ($get_email_run && mysqli_num_rows($get_email_run) > 0) {
            $userData = mysqli_fetch_array($get_email_run);
            $id = $userData['id'];
            
            $get_pin = "SELECT * FROM pin WHERE user_id = '$id'";
            $get_pin_run = mysqli_query($con, $get_pin);

            if ($get_pin_run && mysqli_num_rows($get_pin_run) > 0) {
                $pinData = mysqli_fetch_array($get_pin_run);
                $old_pin = $pinData['code'];

                // Verify current hashed PIN
                if (!password_verify($current, $old_pin)) {
                    http_response_code(401);
                    echo json_encode([
                        'code' => '401',
                        'status' => false,
                        'message' => 'Current pin does not match, Please enter the correct pin and try again.'
                    ]);
                    exit();
                }

                // Prevent using same PIN again
                if (password_verify($pin, $old_pin)) {
                    http_response_code(402);
                    echo json_encode([
                        'code' => '402',
                        'status' => false,
                        'message' => 'New pin matches your old pin, Please enter a new one.'
                    ]);
                    exit();
                }

                // Hash new PIN before saving
                $hashedPin = password_hash($pin, PASSWORD_BCRYPT);

                $updatePin = "UPDATE pin SET code='$hashedPin' WHERE user_id = '$id'";
                $updatePin_run = mysqli_query($con, $updatePin);

                if ($updatePin_run) {
                    // Delete token
                    $updateToken = "DELETE FROM token WHERE token = '$code'";
                    $updateToken_run = mysqli_query($con, $updateToken);
    
                    http_response_code(200);
                    echo json_encode([
                        'code' => '200',
                        'status' => true,
                        'message' => 'Pin changed successfully.'
                    ]);
                } else {
                    http_response_code(500);
                    echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
                    exit();
                }
            } else {
                http_response_code(500);
                echo json_encode(['code' => '500', 'status' => false, 'message' => 'No pin found for this user.']);
                exit();
            }
        } else {
            http_response_code(500);
            echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
            exit();
        }
    } else {   
        http_response_code(500);
        echo json_encode(['code' => '500', 'status' => false, 'message' => 'Invalid or expired Google code, please try again.']);
        exit();
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}
?>