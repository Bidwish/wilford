<?php
include('../../../../config/database.php');
include '../../../headers/post_with_auth.php'; // must contain CORS headers properly


// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    
    $current = $data['password'];
    $code = $data['gCode'];
    $email = $data['email'];
  
    if (empty($current) || empty($code)) {
        echo 400;  // Error: Missing required fields
        exit();
    }
  
    // Validate token
    $reset_query = "SELECT * FROM token WHERE token = '$code' AND email='$email' ";
    $reset_run = mysqli_query($con, $reset_query);

    if ($reset_run && mysqli_num_rows($reset_run) > 0) {   
        // Check if user email exists
        $get_email = "SELECT * FROM users WHERE token = '$token'";
        $get_email_run = mysqli_query($con, $get_email);

        if ($get_email_run && mysqli_num_rows($get_email_run) > 0) {
            $userData = mysqli_fetch_array($get_email_run);
            $old_password = $userData['password'];
            $id = $userData['id'];

            if (!password_verify($current, $old_password)) {
                http_response_code(500); // User creation failed
                echo json_encode(['code' => '500', 'status' => false, 'message' => 'Your Password is incorrect, Please try again']);
                exit();
            } else { 
                // Delete token & pin
                $updateToken = "DELETE FROM pin WHERE user_id = '$id'";
                $updateToken_run = mysqli_query($con, $updateToken);
          
                $updateToken = "DELETE FROM token WHERE token = '$code'";
                $updateToken_run = mysqli_query($con, $updateToken);
       
                http_response_code(200);
                echo json_encode([
                    'code' => '200',
                    'status' => true,
                    'message' => 'Successful sent.'
                ]);     
            }
        } else {
            http_response_code(500); // User creation failed
            echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
            exit();
        }
    } else {
        http_response_code(500); // User creation failed
        echo json_encode(['code' => '500', 'status' => false, 'message' => 'Invalid or expired Google code, please try again.']);
        exit();
    }
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>