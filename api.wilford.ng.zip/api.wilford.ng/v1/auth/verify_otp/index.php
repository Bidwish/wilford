<?php
include('../../../config/database.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    include '../../headers/post.php';

    // Get the raw input just once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log raw input for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);


    $otp =  $data['otp']; // Escape the concatenated OTP for security
    $phone = $data['phone']; 
    
    // Prepare and execute the query
    $otp_query = "SELECT * FROM sms WHERE phone = '$phone' AND status = '0'";
    $otp_run = mysqli_query($con, $otp_query);   
    if ($otp_run && mysqli_num_rows($otp_run) > 0) {
      $otpData = mysqli_fetch_array($otp_run);
      $code = $otpData['code'];     
      // Ensure both OTP and code are strings for strict comparison
      if ((string)$otp === (string)$code) {
        $updateUser = "UPDATE users SET status='1' WHERE phone = '$phone' ";
        $updateUser_run = mysqli_query($con, $updateUser);
        if($updateUser_run) {
          $update = "DELETE FROM sms WHERE phone = '$phone' ";
          $update_run = mysqli_query($con, $update);
          
          http_response_code(200);
          echo json_encode(['code' => '200', 'status' => false, 'message' => 'Failed to send sms, Please try again']);
        } else {
          http_response_code(500);
          echo json_encode(['code' => '500', 'status' => false, 'message' => 'Unknown error occurred, Please try again']);
        }
      } else {
        http_response_code(401);
        echo json_encode(['code' => '401', 'status' => false, 'message' => 'OTP do not match, Please try again']);
      }
    } else {
      http_response_code(400);
      echo json_encode(['code' => '400', 'status' => false, 'message' => 'OTP has been used or expired, Please request a new one']);
    }
} else {
    http_response_code(500);
    echo json_encode(['status' => false, 'message' => 'Invalid request']);
    exit();
}

?>