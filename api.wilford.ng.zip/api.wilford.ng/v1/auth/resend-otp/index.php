<?php
include('../../../config/database.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    include '../../headers/post.php';

    // SMS API Key
    $publicKey = fetchApiKey($con, 11);
    $secretKey = fetchApiKey($con, 12);

    // KudiSMS API endpoint
    $url = "https://my.kudisms.net/api/otp";

    // Get the raw input just once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log raw input for debugging (optional)
    // $logFile = "webhook_log.txt";
    // file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    // file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    $phone = $data['phone']; 
    
    // Prepare and execute the query
    $update = "UPDATE sms SET status='1' WHERE phone = '$phone' ";
    $update_run = mysqli_query($con, $update);
    if($update_run) {
        $code = rand(100000, 999999);
        $otp = "INSERT INTO sms (phone,code,status) VALUES ('$phone','$code', 0)";
        $otp_run = mysqli_query($con, $otp);
        if($otp_run) {
           // Prepare data
           $data = [
               "token"        => "6cKbSrHqVLdDxme94XM5JYga0FtEI3sGoB7nufvjZWUy8TzOhCk1iwpNPARQ2l",
               "senderID"     => "Wilford VTU",
               "recipients"   => '0'.$phone,
               "otp"          => $code,
               "appnamecode"  => "4862309889",
               "templatecode" => "4512991398" 
           ];

           // Send request
           $ch = curl_init();
           curl_setopt($ch, CURLOPT_URL, $url);
           curl_setopt($ch, CURLOPT_POST, true);
           curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           $response = curl_exec($ch);
           curl_close($ch);

           $result = json_decode($response, true);
 
           if (isset($result['status']) && $result['status'] === 'success') {
               http_response_code(200);
               echo json_encode(['code' => '200', 'status' => false, 'message' => 'OTP successfully sent!']);
           } else {
               http_response_code(400);
               echo json_encode(['code' => '400', 'status' => false, 'message' => 'Failed to send OTP!']);
           }               
       } else {
           http_response_code(500);
           echo json_encode(['code' => '500', 'status' => false, 'message' => 'Unknown error occurred, Please try again']);
       }
    } else {
        http_response_code(500);
        echo json_encode(['code' => '500', 'status' => false, 'message' => 'Unknown error occurred, Please try again']);
    }
} else {
    http_response_code(500);
    echo json_encode(['status' => false, 'message' => 'Invalid request']);
    exit();
}

?>