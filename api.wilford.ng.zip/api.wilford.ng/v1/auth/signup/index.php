<?php
include('../../../config/database.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    include '../../headers/post.php';

    // SMS API Key
    $publicKey = fetchApiKey($con, 11);
    $secretKey = fetchApiKey($con, 12);

    // KudiSMS API endpoint
    $url = "https://my.kudisms.net/api/otp";

    // Get raw JSON data
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Optional logging (debug)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Signup hit: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    // Extract fields
    $fname = $data['fname'] ?? '';
    $lname = $data['lname'] ?? '';
    $uname = $data['mname'] ?? '';
    $email = $data['email'] ?? '';
    $normalizedPhone = $data['phone'] ?? '';
    $password = $data['password'] ?? '';
    $referral = $data['referral_code'] ?? null;

    // Hash password
    $hash = password_hash($password, PASSWORD_BCRYPT);

    // === VALIDATION ===
    if (empty($fname) || empty($lname) || empty($uname) || empty($email) || empty($normalizedPhone) || empty($password)) {
        http_response_code(400);
        echo json_encode(['code' => 400, 'status' => false, 'message' => 'All fields are required']);
        exit();
    }

    // Check if email already exists
    $stmt = $con->prepare("SELECT email FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $email_run = $stmt->get_result();
    if ($email_run->num_rows > 0) {
        http_response_code(401);
        echo json_encode(['code' => 401, 'status' => false, 'message' => 'Email already exists, please try again']);
        exit();
    }

    // Check if phone exists in changed_phone
    $stmt = $con->prepare("SELECT phone FROM changed_phone WHERE phone = ?");
    $stmt->bind_param("s", $normalizedPhone);
    $stmt->execute();
    $changed_phone_run = $stmt->get_result();
    if ($changed_phone_run->num_rows > 0) {
        http_response_code(402);
        echo json_encode(['code' => 402, 'status' => false, 'message' => 'Phone number already exists, please try again']);
        exit();
    }

    // Check if phone exists in users
    $stmt = $con->prepare("SELECT phone FROM users WHERE phone = ?");
    $stmt->bind_param("s", $normalizedPhone);
    $stmt->execute();
    $phone_run = $stmt->get_result();
    if ($phone_run->num_rows > 0) {
        http_response_code(403);
        echo json_encode(['code' => 403, 'status' => false, 'message' => 'Phone number already exists, please try again']);
        exit();
    }

    // Validate referral code if provided
    if (!empty($referral)) {
        $stmt = $con->prepare("SELECT code FROM referCode WHERE code = ?");
        $stmt->bind_param("s", $referral);
        $stmt->execute();
        $referral_run = $stmt->get_result();
        if ($referral_run->num_rows === 0) {
            http_response_code(404);
            echo json_encode(['code' => 404, 'status' => false, 'message' => 'Invalid referral code']);
            exit();
        }
    }

    // === INSERT USER ===
    $stmt = $con->prepare("INSERT INTO users (fname, lname, uname, email, phone, password, referral, status) VALUES (?, ?, ?, ?, ?, ?, ?, 0)");
    $stmt->bind_param("sssssss", $fname, $lname, $uname, $email, $normalizedPhone, $hash, $referral);

    if ($stmt->execute()) {
        // Generate OTP
        $code = rand(100000, 999999);
        $otp_stmt = $con->prepare("INSERT INTO sms (phone, code, status) VALUES (?, ?, 0)");
        $otp_stmt->bind_param("si", $normalizedPhone, $code);

        if ($otp_stmt->execute()) {
            // Prepare data
            $data = [
                "token"        => "6cKbSrHqVLdDxme94XM5JYga0FtEI3sGoB7nufvjZWUy8TzOhCk1iwpNPARQ2l",
                "senderID"     => "Wilford VTU",
                "recipients"   => $normalizedPhone,
                "otp"          => $code,
                "appnamecode"  => "4862309889",
                "templatecode" => "4512991398" 
            ];

            // Send request
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);

            $result = json_decode($response, true);
 
            if (isset($result['status']) && $result['status'] === 'success') {
                http_response_code(200);
                echo json_encode(['code' => 200, 'status' => true, 'message' => 'Account created successfully. Verification code sent.']);
                exit();
            } else {
                http_response_code(500);
                echo json_encode(['code' => 500, 'status' => false, 'message' => 'Failed to send SMS, please try again']);
                exit();
            }                                                              
        } else {
            http_response_code(500);
            echo json_encode(['code' => 500, 'status' => false, 'message' => 'Failed to generate verification code']);
            exit();
        }
    } else {
        http_response_code(500);
        echo json_encode(['code' => 500, 'status' => false, 'message' => 'Failed to create account, please try again']);
        exit();
    }
} else {
    http_response_code(405);
    echo json_encode(['status' => false, 'message' => 'Invalid request method']);
    exit();
}
?>
