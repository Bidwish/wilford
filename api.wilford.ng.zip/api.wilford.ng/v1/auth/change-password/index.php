<?php
include('../../../config/database.php');
include '../../headers/post_with_auth.php'; // must contain CORS headers properly


// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }

    $current = $data['cPassword'];
    $code = $data['gCode'];
    $email = $data['email'];
    $password = $data['rPassword'];
    $c_password = $data['nPassword'];

    if ($password !== $c_password) {
        http_response_code(400);
        echo json_encode([
            'code' => '400',
            'status' => false,
            'message' => 'Your new password do not match, Please try again.'
        ]);
        exit();
    }

    // Hash the new password
    $hashed = password_hash($password, PASSWORD_DEFAULT);

    // Validate token
    $reset_query = "SELECT * FROM token WHERE token = '$code' AND email='$email' ";
    $reset_run = mysqli_query($con, $reset_query);

    if ($reset_run && mysqli_num_rows($reset_run) > 0) {
        $tokenData = mysqli_fetch_array($reset_run);
        // $email = $tokenData['email'];
    
        // Check if user email exists
        $get_email = "SELECT * FROM users WHERE token = '$token' AND email = '$email'";
        $get_email_run = mysqli_query($con, $get_email);

        if ($get_email_run && mysqli_num_rows($get_email_run) > 0) {
            $userData = mysqli_fetch_array($get_email_run);
            $old_password = $userData['password'];

            if (!password_verify($current, $old_password)) {
                http_response_code(401);
                echo json_encode([
                    'code' => '401',
                    'status' => false,
                    'message' => 'Current password do not match.'
                ]);
                exit();
            } else {
                // Check if the new password is the same as the old password
                if (password_verify($password, $old_password)) {
                    http_response_code(402);
                    echo json_encode([
                        'code' => '402',
                        'status' => false,
                        'message' => 'New password matches your old password, Please try again.'
                    ]);
                    exit();
                } else {
                    // Update user password
                    $updateUser = "UPDATE users SET password='$hashed' WHERE token = '$token' AND email = '$email'";
                    $updateUser_run = mysqli_query($con, $updateUser);

                    if ($updateUser_run) {
                        // Delete token
                        $updateToken = "DELETE FROM token WHERE token = '$code'";
                        $updateToken_run = mysqli_query($con, $updateToken);
       
                        http_response_code(200);
                        echo json_encode([
                            'code' => '200',
                            'status' => true,
                            'message' => 'Successful sent.'
                        ]);
                    } else {
                        http_response_code(500); // User creation failed
                        echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
                        exit();
                    }
                }
            }
        } else {
            http_response_code(500); // User creation failed
            echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
            exit();
        }
    } else {   
        http_response_code(500); // User creation failed
        echo json_encode(['code' => '500', 'status' => false, 'message' => 'Invalid or expired Google code, please try again.']);
        exit();
    }
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}


?>