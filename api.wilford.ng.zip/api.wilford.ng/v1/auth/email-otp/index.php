<?php
include('../../../config/database.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    include '../../headers/post.php';

    // Get the raw input just once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log raw input for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    $email = $data['email'];    
    $token = rand(100000, 999999); // Generate a random token

    $send_query = "SELECT * FROM users WHERE email = '$email'";
    $send_run = mysqli_query($con, $send_query);

    if (mysqli_num_rows($send_run) > 0) {
        // Update the token table to mark previous tokens as used
        $update = "DELETE FROM token WHERE email = '$email'";
        $update_run = mysqli_query($con, $update);

        // Insert the new token
        $token_query = "INSERT INTO token (email, token, status) VALUES ('$email', '$token', 0)";
        $token_run = mysqli_query($con, $token_query);

        if ($token_run) {
            require "./../../../Mail/phpmailer/PHPMailerAutoload.php";
            $mail = new PHPMailer;

            // SMTP configuration
            $mail->isSMTP();
            $mail->Host = $host;
            $mail->Port = 587;
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'tls';

            $mail->Username = $a_email;
            $mail->Password = $password;

            $mail->setFrom($s_email, $cname);
            $mail->addAddress($email);

            // Email content
            $mail->isHTML(true);
            $mail->Subject = "Verification Code";
            $mail->Body = '
                <div style="font-family: Arial, sans-serif; width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
                    <p style="color: #666; margin-bottom: 40px;">Dear user,</p>
                    <p style="color: #666; margin-bottom: 20px;">An email verification code request has been detected on ' . htmlspecialchars($cname) . '.</p>
                    <p style="color: #666; margin-bottom: 30px;">Please enter the following verification code to complete the operation:</p>
                
                    <p style="color: #333; font-size: 25px; font-weight: bold; text-align: center; margin: 20px 0;">' . htmlspecialchars($token) . '</p>
                
                    <p style="color: #666; margin-top: 30px; margin-bottom: 40px;">The verification code will be valid for 30 minutes. Please do not share your code with anyone.</p>
                    <p style="color: #666; margin-bottom: 10px; font-size: 18px;">
                    Regards,<br>
                    <i> ' . htmlspecialchars($cname) . ' Team</i>
                    </p>
                    <p style="color: #999; font-size: 16px; margin-top: 20px;">This is an automated message. Please do not reply.</p>
                </div>';

            // Send email
            if (!$mail->send()) {                                    
                http_response_code(500);
                echo json_encode(['code' => '500', 'status' => false, 'message' => 'Unknown error occurred, Please try again']);
                exit();
            } else {         
                http_response_code(200);
                echo json_encode(['code' => '200', 'status' => true, 'message' => 'OTP successfully sent!']);
                exit();
            }	
        } else {
            http_response_code(500);
            echo json_encode(['code' => '500', 'status' => false, 'message' => 'Unknown error occurred, Please try again']);
            exit();
        }
    } else {
        http_response_code(500);
        echo json_encode(['code' => '500', 'status' => false, 'message' => 'Unknown error occurred, Please try again']);
        exit();
    } 
} else {
    http_response_code(500);
    echo json_encode(['status' => false, 'message' => 'Invalid request']);
    exit();
}

?>