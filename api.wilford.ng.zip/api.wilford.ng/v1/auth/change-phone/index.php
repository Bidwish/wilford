<?php
include('../../../config/database.php');
include '../../headers/post_with_auth.php'; // must contain CORS headers properly


// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }

    $current = $data['cPhone'];
    $code = $data['gCode'];
    $email = $data['email'];
    $password = $data['passWord'];
    $phone = $data['nPhone'];
    
    // Get the user data
    $stmt = mysqli_prepare($con, "SELECT id FROM users WHERE token = ?");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $userData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    $id = $userData['id'];
    $sPhone = $userData['phone'];
    
    // Check for existing in deleted phone
    $stmt = $con->prepare("SELECT * FROM changed_phone WHERE phone = ?");
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    $email_run = $stmt->get_result();
    if ($email_run->num_rows > 0) {
        http_response_code(402);
        echo json_encode(['code' => '402', 'status' => false, 'message' => 'This Phone number can\'t be used, Please contact support.']);
        exit();
    }
    
    // Check for existing phone number
    $stmt = $con->prepare("SELECT * FROM users WHERE phone = ?");
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    $phone_run = $stmt->get_result();
    if ($phone_run->num_rows > 0) {
        http_response_code(402);
        echo json_encode(['code' => '402', 'status' => false, 'message' => 'Phone number already in use, Please try again']);
        exit();
    }

    // Validate the token
    $reset_query = "SELECT * FROM token WHERE token = '$code' AND email = '$email'";
    $reset_run = mysqli_query($con, $reset_query);

    if ($reset_run && mysqli_num_rows($reset_run) > 0) {
        $tokenData = mysqli_fetch_assoc($reset_run);

        // Get user data
        $get_query = "SELECT * FROM users WHERE id = '$id'";
        $get_run = mysqli_query($con, $get_query);

        if ($get_run && mysqli_num_rows($get_run) > 0) {
            $userData = mysqli_fetch_assoc($get_run);
            $stored_password = $userData['password'];

            // Verify password hash
            if (!password_verify($password, $stored_password)) {
                http_response_code(403);
                echo json_encode([
                    'code' => '403',
                    'status' => true,
                    'message' => 'Invailed password, Please try again.'
                ]);
                exit();
            }

            // Update user phone number
            $update_query = "UPDATE users SET phone = '$phone' WHERE id = '$id'";
            if (mysqli_query($con, $update_query)) {
                // Delete the used token
                $delete_token_query = "DELETE FROM token WHERE token = '$code'";
                mysqli_query($con, $delete_token_query);

                // Log the old phone number
                $log_query = "INSERT INTO changed_phone (phone) VALUES ('$current')";
                mysqli_query($con, $log_query);
                
                http_response_code(200);
                echo json_encode([
                    'code' => '200',
                    'status' => true,
                    'message' => 'Successful sent.'
                ]);
            } else {
                http_response_code(500); // User creation failed
                echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, please try again.']);
                exit();
            }
        } else {
            http_response_code(500); // User creation failed
            echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, please try again.']);
            exit();
        }
    } else {
        http_response_code(402); // User creation failed
        echo json_encode(['code' => '402', 'status' => false, 'message' => 'Invalid or expired Google code, please try again.']);
        exit();
    }
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}


?>