<?php
include('./../../config/database.php');
include './../headers/post_with_auth.php'; // Contains proper CORS headers

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Debug logging (optional)
    file_put_contents("webhook_log.txt", "Login hit: " . date("Y-m-d H:i:s") . "\nData: " . $rawData . "\n", FILE_APPEND);
    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    
    file_put_contents("token.txt", "Login hit: " . date("Y-m-d H:i:s") . "\nData: " . $token . "\n", FILE_APPEND);

    $phone = trim($data['phone'] ?? '');
    $password = trim($data['password'] ?? '');

    // Basic validation
    if (empty($phone) || empty($password)) {
        http_response_code(400);
        echo json_encode([
            'status' => false,
            'message' => 'Phone and password are required.'
        ]);
        exit;
    }

    // Look up the user
    $stmt = $con->prepare("SELECT * FROM users WHERE phone = ? AND token = ?");
    $stmt->bind_param("ss", $phone, $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
        $userPasswordHash = $userData['password'];
        $userId = $userData['id'];

        if (password_verify($password, $userPasswordHash)) {
            // Delete the used pin
            $delete_token_query = "DELETE FROM pin WHERE user_id = '$userId'";
            mysqli_query($con, $delete_token_query);
            
            // Delete the used refer Code
            $delete_referCode_query = "DELETE FROM referCode WHERE user_id = '$userId'";
            mysqli_query($con, $delete_referCode_query);
            
            // Delete the used tickets
            $delete_token_query = "DELETE FROM tickets WHERE user_id = '$userId'";
            mysqli_query($con, $delete_token_query);
            
            // Delete the used tickets
            $delete_tickets_query = "DELETE FROM ticket_chat WHERE user_id = '$userId'";
            mysqli_query($con, $delete_tickets_query);
            
            // Delete the nomba_bank_account
            $delete_user_query = "DELETE FROM nomba_bank_account WHERE id = '$userId'";
            mysqli_query($con, $delete_user_query);
            
            // Delete the used user
            $delete_user_query = "DELETE FROM users WHERE id = '$userId'";
            mysqli_query($con, $delete_user_query);
            
            // Log the deleted phone number
            $log_query = "INSERT INTO changed_phone (phone) VALUES ('$phone')";
            mysqli_query($con, $log_query);

            // Build response
            http_response_code(200);
            echo json_encode([
                'code' => '200',
                'status' => true,
                'message' => 'Successful',
            ]);
        } else {
            http_response_code(401);
            echo json_encode([
                'code' => '401',
                'status' => false,
                'message' => 'Invalid password.'
            ]);
        }
    } else {
        http_response_code(401);
        echo json_encode([
            'code' => '401',
            'status' => false,
            'message' => 'Invalid credentials.'
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
}
?>
