<?php
include('../../../config/database.php');
include '../../headers/post_with_auth.php'; // must contain CORS headers properly


// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    
    $pin = $data['nPin'];
    $c_pin = $data['rPin'];

    if ($pin !== $c_pin) {
        http_response_code(400);
        echo json_encode([
            'code' => '400',
            'status' => false,
            'message' => 'Your Pin do not match, Please try again.'
        ]);
        exit();
    }

    // Validate token
    $get_query = "SELECT * FROM users WHERE token = '$token' ";
    $get_run = mysqli_query($con, $get_query);

    if ($get_run && mysqli_num_rows($get_run) > 0) {
        $userData = mysqli_fetch_array($get_run);
        $id = $userData['id'];
        
        $check = "SELECT user_id FROM pin WHERE user_id = '$id' ";
        $check_run = mysqli_query($con, $check);
        
        if (mysqli_num_rows($check_run)) {
            http_response_code(400);
            echo json_encode([
                'code' => '401',
                'status' => false,
                'message' => 'You have already set Pin.'
            ]);
            exit();
        }
        
        // Update user password
        $set = "INSERT INTO pin (code, user_id) VALUES ('$pin','$id')";
        $set_run = mysqli_query($con, $set);

        if ($set_run) {
            http_response_code(200);
            echo json_encode([
                'code' => '200',
                'status' => true,
                'message' => 'Successful sent.'
            ]);
        } else {
            http_response_code(500); // User creation failed
            echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
            exit();
        }
    } else {
        http_response_code(500); // User creation failed
        echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
        exit();
    }
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}


?>