<?php
include('../../config/database.php');
include './../headers/post_with_auth.php';

date_default_timezone_set('Africa/Lagos');

// Endpoint URL
$url = 'https://vtpass.com/api/pay';

// Get the Secret Key from the database 
$api = "SELECT * FROM api_keys WHERE name = 'VTPass_secret_key'";
$api_run = mysqli_query($con, $api);
$apiData = mysqli_fetch_assoc($api_run);
$secret_key = $apiData['key'];

// Get the API Key from the database 
$apis = "SELECT * FROM api_keys WHERE name = 'VTPass_api_key'";
$apis_run = mysqli_query($con, $apis);
$apisData = mysqli_fetch_assoc($apis_run);
$api_key = $apisData['key'];

$requestId = null;
$today = date('Ymd');
$hourMinute = date('Hi');
$randomPart = substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyz'), 0, 12);

// Generate the Request ID if not provided
if ($requestId === null) {
  $requestId = $today . $hourMinute . $randomPart;
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    $amount = $data['amount'];
    $cleanedPhone = str_replace(' ', '', $data['phone']);
    $phone = $cleanedPhone;
    $network = $data['network'];  
    $method = '3';
    $user_id = $data['user_id'];
    $pin = $data['pin']; 
    
    // cross network for points and commission
    if ($network == 'mtn') {
      $commission = ($amount / 100) * 2;
      $pts = ($amount / 100) * 1;
    } else if ($network == 'glo' || $network == 'etisalat') {   
      $commission = ($amount / 100) * 3;
      $pts = ($amount / 100) * 1;
    } else if ($network == 'airtel') {
      $commission = ($amount / 100) * 2.4;
      $pts = ($amount / 100) * 1;
    } else {
        $commission = 0;
        $pts = 0;
    }

    // Securely Verify Hashed Pin
    $pin_query = "SELECT * FROM pin WHERE user_id = ?";
    $stmt = mysqli_prepare($con, $pin_query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $pin_run = mysqli_stmt_get_result($stmt);
    
    if ($pin_run && mysqli_num_rows($pin_run) > 0) {
        $pinData = mysqli_fetch_assoc($pin_run);
        $hashedPin = $pinData['code'];
    
        if (password_verify($pin, $hashedPin)) {  // Secure verification
            // Fetch user balance
            $stmt = mysqli_prepare($con, "SELECT bala FROM users WHERE id = ? AND token = ?");
            mysqli_stmt_bind_param($stmt, "is", $user_id, $token);
            mysqli_stmt_execute($stmt);
            $userData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            $bala = $userData['bala'];
    
            if ($bala >= $amount) {
                // Update balances
                $new_sender_balance = $bala - $amount + $pts;                
                $stmt = mysqli_prepare($con, "UPDATE users SET bala = ? WHERE id = ?");
                mysqli_stmt_bind_param($stmt, "ii", $new_sender_balance, $user_id);
                mysqli_stmt_execute($stmt);
                
                if (mysqli_stmt_affected_rows($stmt) > 0) {
                    // Data to be sent in the request
                    $data = array(
                        'request_id' => $requestId,
                        'serviceID' => $network,         
                        'amount' => $amount,         
                        'phone' => $phone, 
                        'request_id' => $requestId 
                    );
              
                    // Initialize cURL session
                    $ch = curl_init();
    
                    // Set request headers
                    $headers = array(
                        "api-key: $api_key",
                        "secret-key: $secret_key"
                    );
              
                    // Set cURL options
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
              
                    // Execute cURL request
                    $response = curl_exec($ch);
              
                    if ($response === false) {
                        // Handle cURL error
                    } else {
                        $response_data = json_decode($response, true);
                        $transactionId = $response_data['content']['transactions']['transactionId'] ?? '';
                        $code = $response_data['code'];
                        if($code == 000){
                           $stmt = mysqli_prepare($con, "INSERT INTO payments (payment_id, transactionId, user_id, method, status, amount, phone, network, pts, adminCommission, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                            $status = "successful";
                            $payment_id = generate21DigitNumber();
                            mysqli_stmt_bind_param($stmt, "iiiisiissss", $payment_id, $transactionId, $user_id, $method, $status, $amount, $phone, $network, $pts, $commission, $now);
                            mysqli_stmt_execute($stmt);
                            
                            adminCommission($con, $commission);    
                            $_SESSION['success'] = "The recipient account is expected to be credited within 5 minutes.";
                            http_response_code(200);
                            echo json_encode([
                                'code' => '200',
                                'status' => true,
                                'message' => 'Successful sent.'
                            ]);
                        } else {
                            // Store failed details and refund
                            $stmt = mysqli_prepare($con, "INSERT INTO payments (payment_id, transactionId, user_id, method, status, amount, phone, network, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                            $status = "failed";
                            $payment_id = generate21DigitNumber();
                            mysqli_stmt_bind_param($stmt, "iiiisiiss", $payment_id, $transactionId, $user_id, $method, $status, $amount, $phone, $network, $now);
                            mysqli_stmt_execute($stmt);
                
                            // Refund
                            $new_balance = $bala;                
                            $stmt = mysqli_prepare($con, "UPDATE users SET bala = ? WHERE id = ?");
                            mysqli_stmt_bind_param($stmt, "ii", $new_balance, $user_id);
                            mysqli_stmt_execute($stmt);
                            
                            http_response_code(403);
                            echo json_encode([
                                'code' => '403',
                                'status' => false,
                                'message' => 'Transaction failed. Please try again.'
                            ]); 
                        }
                    }
                    curl_close($ch);
    
                    return $response;
                } else {                   
                    http_response_code(500);
                    echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again']);
                    exit();
                }
            } else {
                http_response_code(402);
                echo json_encode([
                    'code' => '402',
                    'status' => false,
                    'message' => 'Insufficient Balance, Please fund your account and try again.'
                ]); 
            }
        } else {
            // Incorrect hashed PIN
            http_response_code(401);
            echo json_encode([
                'code' => '401',
                'status' => false,
                'message' => 'Incorrect Pin, Please try again.'
            ]);
            exit();
        }
    } else {
        http_response_code(400);
        echo json_encode([
            'code' => '400',
            'status' => false,
            'message' => 'Please set your transaction Pin to proceed.'
        ]);
        exit();
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}
?>