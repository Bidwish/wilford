<?php
include('./../../config/database.php');
include './../headers/post_with_auth.php'; // must contain CORS headers properly

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    // Validate token
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode(['status' => false, 'message' => 'Authorization header missing.']);
        exit;
    }

    list($type, $token) = explode(' ', $authHeader, 2);
    if (strcasecmp($type, 'Bearer') !== 0 || empty($token)) {
        http_response_code(401);
        echo json_encode(['status' => false, 'message' => 'Invalid token format.']);
        exit;
    }

    // Get request payload
    $rawData = file_get_contents("php://input");
    $body = json_decode($rawData, true);

    $referralCode = trim($body['referral'] ?? '');

    if (empty($referralCode)) {
        http_response_code(400);
        echo json_encode(['status' => false, 'message' => 'Referral code is required.']);
        exit;
    }

    // Query users with referral code
    $query = "SELECT fname, uname, lname, profile FROM users WHERE referral = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("s", $referralCode);
    $stmt->execute();
    $result = $stmt->get_result();

    $uniqueAccounts = [];

    if ($result && $result->num_rows > 0) {
        while ($item = $result->fetch_assoc()) {
            $name = $item['fname'] . ' ' . $item['uname'] . ' ' . $item['lname'];
            $image = !empty($item['profile']) 
                ? 'https://image.wilford.ng/profile/' . urlencode($item['profile']) 
                : null;

            $uniqueAccounts[] = [
                'name' => $name,
                'image' => $image,
            ];
        }

        http_response_code(200);
        echo json_encode([
            'success' => true,
            'data' => $uniqueAccounts
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'No users found for this referral code.'
        ]);
    }
} else { 
    http_response_code(405); // Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}
?>
