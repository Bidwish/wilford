<?php
include('./../../../config/database.php');
include './../../headers/get.php'; // Set correct CORS headers for GET requests

function generateReferralCode($length = 6) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $referralCode = '';

    for ($i = 0; $i < $length; $i++) {
        $referralCode .= $characters[rand(0, $charactersLength - 1)];
    }

    return $referralCode;
}

function getOrCreateReferralCode($userId, $con, $length = 6) {
    // Check if the user already has a referral code
    $query = "SELECT code FROM referCode WHERE user_id = ?";
    $checkStmt = $con->prepare($query);
    $checkStmt->bind_param("i", $userId);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $row = $result->fetch_assoc();

    if ($row) {
        return $row['code'];
    }

    // Generate a unique referral code
    do {
        $referralCode = generateReferralCode($length);
        $checkQuery = "SELECT COUNT(*) AS count FROM referCode WHERE code = ?";
        $existsStmt = $con->prepare($checkQuery);
        $existsStmt->bind_param("s", $referralCode);
        $existsStmt->execute();
        $existsResult = $existsStmt->get_result();
        $existsRow = $existsResult->fetch_assoc();
        $exists = $existsRow['count'];
    } while ($exists > 0);

    // Insert the new referral code
    $insertQuery = "INSERT INTO referCode (user_id, code) VALUES (?, ?)";
    $insertStmt = $con->prepare($insertQuery);
    $insertStmt->bind_param("is", $userId, $referralCode);
    $insertStmt->execute();

    return $referralCode;
}

// Handle GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    if (!$authHeader) {
        http_response_code(401);
        echo json_encode(['status' => false, 'message' => 'Authorization header missing.']);
        exit;
    }

    list($type, $token) = explode(' ', $authHeader, 2);
    if (strcasecmp($type, 'Bearer') !== 0 || empty($token)) {
        http_response_code(401);
        echo json_encode(['status' => false, 'message' => 'Invalid token format.']);
        exit;
    }

    $stmt = $con->prepare("SELECT id FROM users WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
        $userId = $userData['id'];

        $code = getOrCreateReferralCode($userId, $con);

        if ($code) {
            http_response_code(200);
            echo json_encode([
                'status' => true,
                'referral_code' => $code
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'status' => false,
                'message' => 'Failed to generate referral code.'
            ]);
        }
    } else {
        http_response_code(404);
        echo json_encode([
            'status' => false,
            'message' => 'Account not found.'
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
}
?>
