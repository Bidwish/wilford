<?php
include('../../../config/database.php');
header('Content-Type: application/json');

// Assume $con is already initialized (mysqli connection)
$dataPlans = [];

$get = "SELECT * FROM datas";
$get_run = mysqli_query($con, $get);

if ($get_run) {
    while ($plan = mysqli_fetch_assoc($get_run)) {
        $earn = ($plan['amount'] / 100) * 1;

        $dataPlans[] = [
            'name' => $plan['name'],
            'amount' => $plan['amount'],
            'validity' => $plan['code'],
            'note' => $plan['note'],
            'duration' => $plan['duration'],
            'network' => $plan['network'],           
            'type' => $plan['type'],
            'earn' => round($earn, 2)
        ];
    }

    $response = [
        'success' => true,
        'data' => $dataPlans
    ];
} else {
    $response = [
        'success' => false,
        'message' => 'Failed to fetch data plans'
    ];
}

echo json_encode($response);
?>