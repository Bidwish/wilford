<?php
include('./../../config/database.php');
header('Content-Type: application/json');

// Assume $con is already initialized (mysqli connection)
$banners = [];

$page = $_GET['screen'];

$get = "SELECT * FROM sliders WHERE pages = '$page'";
$get_run = mysqli_query($con, $get);

if ($get_run) {
    while ($plan = mysqli_fetch_assoc($get_run)) {
        $banners[] = [
            'imageUrl' => 'https://image.wilford.ng/slider/'.$plan['images'],
            'targetScreen' => $plan['pages']
        ];
    }

    $response = [
        'success' => true,
        'data' => $banners
    ];
} else {
    $response = [
        'success' => false,
        'message' => 'Failed to fetch slider'
    ];
}

echo json_encode($response);
?>