<?php
function sendEmail($userFullName, $amount, $balance, $recipientName, $bank, $accountNumber, $transactionId, $transactionDate, $email, $con, $mail) {
    // Get SMTP
    $smtp = "SELECT email, password, host, name, api_email FROM smtp";
    $smtp_run = mysqli_query($con, $smtp);
    $smtpData = mysqli_fetch_assoc($smtp_run);
    $host = $smtpData['host'];
    $s_email = $smtpData['email'];
    $a_email = $smtpData['api_email'];
    $cname = $smtpData['name'];
    $password = $smtpData['password'];

    // SMTP configuration
    $mail->isSMTP();
    $mail->Host = $host;
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    $mail->Username = $a_email;
    $mail->Password = $password;

    $mail->setFrom($s_email, $cname);
    $mail->addAddress($email);

    // Email content
    $mail->isHTML(true);
    $mail->Subject = 'Transfer Successful';
    
    $mail->Body = "
        <!DOCTYPE html>
        <html lang='en'>
            <head>
              <meta charset='UTF-8'>
              <title>Transaction Notification</title>
            </head>
            <body style='margin: 0; padding: 0; background-color: #fff; font-family: Arial, sans-serif; color: #000; font-size: 14px;'>
            
              <table width='100%' cellpadding='0' cellspacing='0' style='max-width: 600px; margin: auto; padding: 20px;'>
            
                <!-- Logo -->
                <tr>
                  <td style='text-align: center; padding-bottom: 20px;'>
                    <img src='https://image.wilford.ng/logo.png' alt='Your Logo' style='height: 40px;'>
                  </td>
                </tr>
            
                <!-- Greeting and Summary -->
                <tr>
                  <td style='padding-bottom: 20px; line-height: 1.6;'>
                    <strong>Dear {$userFullName},</strong><br>
                    Your transfer of <strong>₦{$amount}</strong> is successful. Your available balance is <strong>₦{$balance}</strong>.
                  </td>
                </tr>
            
                <!-- Dashed Divider -->
                <tr>
                  <td>
                    <hr style='border: none; border-top: 1px dashed #ccc; margin: 20px 0;'>
                  </td>
                </tr>
            
                <!-- Transfer Details Header -->
                <tr>
                  <td style='padding-bottom: 10px;'>
                    <strong>Transfer Details:</strong>
                  </td>
                </tr>
            
                <!-- Transfer Details Fields -->
                <tr><td style='padding: 6px 0;'>Name:<br><strong>{$recipientName}</strong></td></tr>
                <tr><td style='padding: 6px 0;'>Bank:<br><strong>{$bank}</strong></td></tr>
                <tr><td style='padding: 6px 0;'>Account Number:<br><strong>{$accountNumber}</strong></td></tr>
                <tr><td style='padding: 6px 0;'>Amount:<br><strong>₦{$amount}</strong></td></tr>
                <tr><td style='padding: 6px 0;'>Transaction No.:<br><strong>{$transactionId}</strong></td></tr>
                <tr><td style='padding: 6px 0;'>Transaction Date:<br><strong>{$transactionDate}</strong></td></tr>
            
                <!-- Dashed Divider --> 
                <tr>
                  <td>
                    <hr style='border: none; border-top: 1px dashed #ccc; margin: 20px 0;'>
                  </td>
                </tr>
            
                <!-- Support Section -->
                <tr>
                  <td style='line-height: 1.6;'>
                    For further enquiries, please contact our customer support through the following channels:<br><br>
                    Phone: <strong>+234 702 574 4517</strong><br>
                    Email: <a href='mailto:support@wilford.ng' style='color: #0000ee; text-decoration: underline;'>support@wilford.ng</a>
                  </td>
                </tr>
              </table>
            </body>
        </html>
    ";

    // Send email
    if (!$mail->send()) {                                    
        http_response_code(500);
    } 
}

?>
