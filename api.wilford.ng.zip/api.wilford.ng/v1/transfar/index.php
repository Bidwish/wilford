<?php
include('./../../config/database.php');
include './../headers/post_with_auth.php';
include '../functions/send_email.php';
include './../../fcm/index.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
     
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    // $logFile = "webhook_log.txt";
    // file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    // file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    $c_amount = $data['amount'];
    $remark = $data['remark'];
    $receivedAccountName = $data['accountName'];
    $senderName = $data['senderName'];
    $receivedAccountNumber = $data['accountNumber'];
    $senderAccountNumber = $data['phone'];
    $user_id = $data['user_id'];
    $bankCode = '0000';
    $bankName = 'Wilford';
    $pin = $data['pin']; 
    $method = '1';
    
    $amount = str_replace(",", "", $c_amount);

    // Verify Pin
    $pin_query = "SELECT * FROM pin WHERE user_id = ?";
    $stmt = mysqli_prepare($con, $pin_query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $pin_run = mysqli_stmt_get_result($stmt);

    if ($pin_run && mysqli_num_rows($pin_run) > 0) {
        $pinData = mysqli_fetch_assoc($pin_run);
        $hashedPin = $pinData['code'];

        if (password_verify($pin, $hashedPin)) {
            // Fetch user balance
            $stmt = mysqli_prepare($con, "SELECT bala, email FROM users WHERE id = ? AND token = ?");
            mysqli_stmt_bind_param($stmt, "is", $user_id, $token);
            mysqli_stmt_execute($stmt);
            $userData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            $bala = $userData['bala'];
            $email = $userData['email'];

            if ($bala >= $amount) {
                // Update balances
                $new_sender_balance = $bala - $amount;                
                $stmt = mysqli_prepare($con, "UPDATE users SET bala = ? WHERE id = ?");
                mysqli_stmt_bind_param($stmt, "ii", $new_sender_balance, $user_id);
                mysqli_stmt_execute($stmt);
            
                if (mysqli_stmt_affected_rows($stmt) > 0) {
                    // Get User Id
                    $kyc = $con->prepare("SELECT id FROM users WHERE phone = ?");
                    $kyc->bind_param("s", $receivedAccountNumber);
                    $kyc->execute();
                    $kyc->bind_result($rec_id);
                    $kyc->fetch();
                    $kyc->close();
        
                    // Fetch receiver balance
                    $stmt = mysqli_prepare($con, "SELECT bala FROM users WHERE id = ?");
                    mysqli_stmt_bind_param($stmt, "i", $rec_id);
                    mysqli_stmt_execute($stmt);
                    $recData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
                    $rec_bala = $recData['bala'];

                    // Update balances
                    $new_sender_balance = $bala - $amount;
                    $new_receiver_balance = $rec_bala + $amount;

                    $stmt = mysqli_prepare($con, "UPDATE users SET bala = ? WHERE id = ?");
                    mysqli_stmt_bind_param($stmt, "ii", $new_sender_balance, $user_id);
                    mysqli_stmt_execute($stmt);

                    mysqli_stmt_bind_param($stmt, "ii", $new_receiver_balance, $rec_id);
                    mysqli_stmt_execute($stmt);

                    if (mysqli_stmt_affected_rows($stmt) > 0) {
                        $payment_id = generate21DigitNumber();
                        $transactionId = generate21DigitNumber();
                        $payment_status = "successful";
                        
                        // Send Email
                        require "../../Mail/phpmailer/PHPMailerAutoload.php";
                        $mail = new PHPMailer;
                        $transactionDate = getNigeriaDateTime();
                        
                        // Save notification 
                        notification($con,$payment_id,$rec_id,$senderName,$amount,$transactionDate);
                        
                        sendEmail($senderName, $c_amount, $new_sender_balance, $receivedAccountName, $bankName, $receivedAccountNumber, $payment_id, $transactionDate, $email, $con, $mail);
                    
                        $stmt = $con->prepare("INSERT INTO payments (payment_id, user_id, rec_id, amount, method, status, transactionId, remark, senderAccNumber, senderAccName, senderBank, recAccNumber, recAccName, created_at, senderCode, recBank, recCode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssssssssssssssss", $payment_id, $user_id, $rec_id, $amount, $method, $payment_status, $transactionId, $remark, $senderAccountNumber, $senderName, $bankName, $receivedAccountNumber, $receivedAccountName, $now, $bankCode, $bankName, $bankCode);
                        $stmt->execute();
                        $stmt->close();
                        
                        // Get FCM Token
                        $fcm = $con->prepare("SELECT fcm_token FROM users WHERE id = ?");
                        $fcm->bind_param("i", $rec_id);
                        $fcm->execute();
                        $fcmResult = $fcm->get_result();
                        $fcmToken = $fcmResult->fetch_assoc();
                        
                        // Send FCM notification
                        sendFCM(
                            'Incoming Transfer Successful',
                            "{$senderName} has sent you ₦{$amount}. Get 6% bonus on Wilford Airtime and Data.",
                            $fcmToken['fcm_token']
                        );
                    
                        http_response_code(200);
                        echo json_encode([
                            'code' => '200',
                            'status' => false,
                            'message' => 'Successful sent.'
                        ]);
                    } else {
                        // Refound the user 
                        $new_balance = $bala;                
                        $stmt = mysqli_prepare($con, "UPDATE users SET bala = ? WHERE id = ?");
                        mysqli_stmt_bind_param($stmt, "ii", $new_balance, $user_id);
                        mysqli_stmt_execute($stmt);
                        $_SESSION['error'] = "Transaction Failed, Please try again in few minutes.";
                           
                        http_response_code(408); // User creation failed
                        echo json_encode(['code' => '408', 'status' => false, 'message' => 'Something went wrong, Please try again']);
                        exit();
                    }
                } else {                   
                    http_response_code(500); // User creation failed
                    echo json_encode(['code' => '500', 'status' => false, 'message' => 'Something went wrong, Please try again!']);
                    exit();
                }
            } else {
                http_response_code(402);
                echo json_encode([
                    'code' => '402',
                    'status' => false,
                    'message' => 'Insufficient Balance, Please found your account and try again.'
                ]); 
            }
        } else {
            http_response_code(401);
            echo json_encode([
                'code' => '401',
                'status' => false,
                'message' => 'Incorrect Pin, Please try again.'
            ]);
            exit();
        }
    } else {
        http_response_code(400);
        echo json_encode([
            'code' => '400',
            'status' => false,
            'message' => 'Please Set your transaction Pin to proceed.'
        ]); 
        exit();
    } 
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

Function transactionRecode($payment_id, $user_id, $amount, $method, $fee, $payment_status, $transactionId, $remark, $senderAccountNumber, $senderName, $bankName, $receivedAccountNumber, $receivedAccountName, $con) {
    $stmt = $con->prepare("INSERT INTO payments (payment_id, user_id, amount, method, fee, status, transactionId, remark, senderAccNumber, senderAccName, recBank, recAccNumber, recAccName) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssssss", $payment_id, $user_id, $amount, $method, $fee, $payment_status, $transactionId, $remark, $senderAccountNumber, $senderName, $bankName, $receivedAccountNumber, $receivedAccountName);
    $stmt->execute();
    $stmt->close();
}

?>