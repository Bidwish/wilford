<?php
include('../../../config/database.php');
header('Content-Type: application/json');
include '../../../access_token/index.php';

    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    // $logFile = "webhook_log.txt";
    // file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    // file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);
    
    // API key
    $accountId = fetchApiKey($con, 7);
    $accessToken = fetchApiKey($con, 8);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $data['bank_code'] ?? null;
    $accNumber = $data['account_number'] ?? null; 

    if ($code == 0000) {
        $kyc = $con->prepare("SELECT id, fname, uname, lname, profile, phone FROM users WHERE phone = ? OR email = ?");
        $kyc->bind_param("ss", $accNumber, $accNumber);
        $kyc->execute();
        $kyc->bind_result($id, $fname, $uname, $lname, $image, $phone);
        $kyc->fetch();
        $kyc->close();
        $name = $fname .' '.$uname. ' '.$lname;
            
        if (empty($fname)) {
            http_response_code(401);
            echo json_encode([
                'status' => 'failed',
                'message' => 'Account verification failed. Please check the details or try again later.'
            ]);
        } else {
            http_response_code(201);
            echo json_encode([
                'code' => '000',
                'status' => 'success',
                'account_name' => $name,
                'account_number' => $phone,
                'image' => 'https://image.wilford.ng/profile/'.$image
            ]);
        }
    } else {
        $requestData = [
            "accountNumber" => $accNumber,
            "bankCode" => $code
        ];

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.nomba.com/v1/transfers/bank/lookup",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($requestData),
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer " . $accessToken, // Replace securely
                "Content-Type: application/json",
                "accountId: ".$accountId
            ],
        ]);

        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
           // echo '<div class="bg-red-200 bg-opacity-40 text-red-800 px-2 pt-2 pb-1 mt-2 flex items-center space-x-1 rounded-lg dark:bg-red-100">
           //         <i class="text-base fi fi-ss-shield-xmark"></i>
           //         <p class="text-xs mb-1"> cURL Error: ' . htmlspecialchars($err) . ' </p>
           //       </div>';
            http_response_code(401);
            echo json_encode([
                'status' => 'failed',
                'message' => 'Account verification failed. Please check the details or try again later.'
            ]);
        } else {
            $data = json_decode($response, true);
            // Debugging (remove this in production)
            // echo "<pre>"; print_r($data); echo "</pre>";

            if ($httpCode === 200 && isset($data['data']['accountName'])) {
                $name = $data['data']['accountName'];
                if(isset($_SESSION['rec'])){
                  unset($_SESSION['rec']);
                }
                
                http_response_code(200);
                echo json_encode([
                    'code' => '001',
                    'status' => 'success',
                    'account_name' => $name
                ]);
            } else {
                http_response_code(401);
                echo json_encode([
                    'status' => 'failed',
                    'message' => 'Account verification failed. Please check the details or try again later.'
                ]);
            }
        }
    }
}

?>