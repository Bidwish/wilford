<?php
include('../../../../config/database.php');
header('Content-Type: application/json');

// Assume $con is already initialized (mysqli connection)
$meter = [];

$get = "SELECT * FROM banks";
$get_run = mysqli_query($con, $get);

if ($get_run) {
    while ($plan = mysqli_fetch_assoc($get_run)) {
        $meter[] = [
            'name' => $plan['name'],
            'image' => 'https://image.wilford.ng/banks/'.$plan['image'],
            'validity' => $plan['code']
        ];
    }

    $response = [
        'success' => true,
        'data' => $meter
    ];
} else {
    $response = [
        'success' => false,
        'message' => 'Failed to fetch data plans'
    ];
}

echo json_encode($response);
?>