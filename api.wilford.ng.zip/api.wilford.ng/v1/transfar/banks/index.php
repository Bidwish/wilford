<?php
include('../../../config/database.php');
include './../../headers/post_with_auth.php';
include '../../../access_token/index.php';
include '../../functions/send_email.php';

function generateRandomCode($length = 13) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomCode = '';
    for ($i = 0; $i < $length; $i++) {
        $randomCode .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomCode;
}

// API Keys
$accountId = fetchApiKey($con, 7);
$accessToken = fetchApiKey($con, 8);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Debug log
    $logFile = "transfer_log.txt";
    file_put_contents($logFile, "Transfer hit at: " . date("Y-m-d H:i:s") . "\nRaw: " . $rawData . "\n", FILE_APPEND);

    if (!$authHeader) {
        http_response_code(401);
        echo json_encode(['status' => false, 'message' => 'Missing Authorization header.']);
        exit;
    }

    list($type, $token) = explode(' ', $authHeader, 2);
    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode(['status' => false, 'message' => 'Invalid token format.']);
        exit;
    }

    // Extract request fields
    $amount = floatval(str_replace(",", "", $data['amount']));
    $fee = 30; // Fee applied to sender immediately
    $totalAmount = $amount + $fee;

    $user_id = intval($data['user_id']);
    $pin = $data['pin'];
    $remark = $data['remark'] ?? '';
    $receivedAccountNumber = $data['accountNumber'];
    $receivedAccountName = $data['accountName'];
    $bankCode = $data['bankCode'];
    $bankName = $data['bankName'];
    $senderName = strtoupper($data['senderName']);
    $senderAccountNumber = $data['phone'];

    // Validate Pin
    $pin_query = $con->prepare("SELECT code FROM pin WHERE user_id = ?");
    $pin_query->bind_param("i", $user_id);
    $pin_query->execute();
    $pin_result = $pin_query->get_result();

    if ($pin_result->num_rows == 0) {
        http_response_code(400);
        echo json_encode(['status' => false, 'message' => 'Please set your transaction pin first.']);
        exit;
    }

    $pinData = $pin_result->fetch_assoc();
    $hashedPin = $pinData['code'];
    if (password_verify($pin, $hashedPin)) {
        http_response_code(401);
        echo json_encode(['status' => false, 'message' => 'Incorrect PIN.']);
        exit;
    }

    // Verify token and balance
    $stmt = $con->prepare("SELECT bala, email FROM users WHERE id = ? AND token = ?");
    $stmt->bind_param("is", $user_id, $token);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) {
        http_response_code(403);
        echo json_encode(['status' => false, 'message' => 'Unauthorized or invalid user.']);
        exit;
    }

    if ($user['bala'] < $totalAmount) {
        http_response_code(402);
        echo json_encode(['status' => false, 'message' => 'Insufficient balance.']);
        exit;
    }

    // Reserve funds (temporarily deduct pending)
    $newBalance = $user['bala'] - $totalAmount;
    $con->query("UPDATE users SET bala = $newBalance WHERE id = $user_id");

    // Generate transaction reference
    $merchantTxRef = "WFT_" . generateRandomCode();

    // Record as PENDING
    $payment_id = generate21DigitNumber();
    $created_at = getNigeriaDateTime();
    $method = '2';
    $status = "pending";
    $senderBank = "Wilford";
    $senderCode = "0000";

    $stmt = $con->prepare("INSERT INTO payments 
        (payment_id, rec_id, amount, method, fee, status, transactionId, remark, senderAccNumber, senderAccName, senderBank, recBank, recAccNumber, recAccName, requestId, created_at, recCode, senderCode)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("siisssssssssssssss", 
        $payment_id, $user_id, $amount, $method, $fee, $status, $merchantTxRef, $remark,
        $senderAccountNumber, $senderName, $senderBank, $bankName, $receivedAccountNumber, $receivedAccountName,
        $merchantTxRef, $created_at, $bankCode, $senderCode
    );
    $stmt->execute();

    // Initiate transfer to Nomba API
    $requestData = [
        "amount" => $amount,
        "accountNumber" => $receivedAccountNumber,
        "accountName" => $receivedAccountName,
        "bankCode" => $bankCode,
        "merchantTxRef" => $merchantTxRef,
        "senderName" => $senderName,
        "narration" => $remark . " / Wilford VTU /"
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api.nomba.com/v1/transfers/bank",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($requestData),
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer " . $accessToken,
            "Content-Type: application/json",
            "accountId: " . $accountId
        ],
    ]);

    $response = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $err = curl_error($curl);
    curl_close($curl);

    // if ($err || $httpCode !== 200) {
         // Mark as failed and refund
    //     $con->query("UPDATE users SET bala = bala + $totalAmount WHERE id = $user_id");
    //     $con->query("UPDATE payments SET status='failed' WHERE transactionId='$merchantTxRef'");
    //     http_response_code(404);
    //     echo json_encode(['status' => false, 'message' => 'Failed to initiate transfer.']);
    //     exit;
    // }
    
    // Send Email
    require "../../../Mail/phpmailer/PHPMailerAutoload.php";
    $mail = new PHPMailer;   
    $email = $user['email'];                        
    sendEmail($senderName, $amount, $newBalance, $receivedAccountName, $bankName, $receivedAccountNumber, $payment_id, $created_at, $email, $con, $mail);

    // Successful initiation (not completion)
    http_response_code(200);
    echo json_encode([
        'status' => true,
        'message' => 'Transfer initiated. Awaiting confirmation from Nomba.'
    ]);
}
else {
    http_response_code(405);
    echo json_encode(['status' => false, 'message' => 'Invalid request method.']);
}
?>