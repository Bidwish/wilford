<?php
include('../../../config/database.php');
include '../../headers/get.php';

// Get the Authorization header
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

// Debug log (optional)
file_put_contents("webhook_log.txt", "Webhook hit at: " . date("Y-m-d H:i:s") . "\nAuthorization: " . $authHeader . "\n", FILE_APPEND);

// Validate header
if (!$authHeader) {
    http_response_code(401);
    echo json_encode([
        'status' => false,
        'message' => 'Authorization header missing.'
    ]);
    exit;
}

// Split "Bearer <token>"
list($type, $token) = explode(' ', $authHeader, 2);
if (strcasecmp($type, 'Bearer') !== 0 || empty($token)) {
    http_response_code(401);
    echo json_encode([
        'status' => false,
        'message' => 'Invalid token format.'
    ]);
    exit;
}

// Lookup user by token
$userStmt = $con->prepare("SELECT id FROM users WHERE token = ?");
$userStmt->bind_param("s", $token);
$userStmt->execute();
$userResult = $userStmt->get_result();

if ($userResult->num_rows === 0) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid token or user not found.'
    ]);
    exit;
}

$userData = $userResult->fetch_assoc();
$userId = $userData['id'];

// Prepare to fetch recent recipients
$account = [];

$query = "
  SELECT DISTINCT u.id, u.fname, u.uname, u.lname, u.phone, u.profile
  FROM payments p
  INNER JOIN users u ON p.rec_id = u.id
  WHERE p.user_id = ? AND p.method = 1
  ORDER BY p.created_at DESC
  LIMIT 5
";

$recipientStmt = $con->prepare($query);
$recipientStmt->bind_param("s", $userId);
$recipientStmt->execute();
$recipientResult = $recipientStmt->get_result();

if ($recipientResult && $recipientResult->num_rows > 0) {
    $uniqueAccounts = [];

    while ($rec = $recipientResult->fetch_assoc()) {
        $key = $rec['phone']; // Using phone as unique identifier
        $name = $rec['lname'] . ' ' . $rec['fname'] . ' ' . $rec['uname'];

        if (!isset($uniqueAccounts[$key])) {
            $uniqueAccounts[$key] = [
                'accountName' => $name,
                'accountNumber' => $rec['phone'],
                'bankName' => 'Wilford',
                'bankCode' => '0000',
                'image' => 'https://image.wilford.ng/profile/' . urlencode($rec['profile']),
            ];
        }
    }

    echo json_encode([
        'success' => true,
        'data' => array_values($uniqueAccounts)
    ]);
} else {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'message' => 'No recent recipients found.'
    ]);
}
?>
