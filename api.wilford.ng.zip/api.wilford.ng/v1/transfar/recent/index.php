<?php
include('../../../config/database.php');
include '../../headers/get.php';

    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = $authHeader;
    $data = $authHeader;

    // Log for debugging (optional)
    // $logFile = "webhook_log.txt";
    // file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    // file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }

    // Lookup user by token (assuming token is email or any saved token)
    $stmt = $con->prepare("SELECT id FROM users WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
        $id = $userData['id'];

        $account = [];

        // Fetch 3 most recent unique recipients by account number
        $query = "
            SELECT DISTINCT p.recAccNumber, p.recAccName, p.recBank, b.name, b.image
            FROM payments p
            INNER JOIN banks b ON p.recBank = b.code
            WHERE p.user_id = ? AND p.method = 2
            ORDER BY p.created_at DESC
        ";

        $stmt = $con->prepare($query);
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $uniqueAccounts = [];

            while ($rec = $result->fetch_assoc()) {
                $key = $rec['recAccNumber'];

                if (!isset($uniqueAccounts[$key])) {
                    $uniqueAccounts[$key] = [
                        'accountName' => $rec['recAccName'],
                        'accountNumber' => $rec['recAccNumber'],
                        'bankName' => $rec['name'],
                        'bankCode' => $rec['recBank'],
                        'image' => 'https://image.wilford.ng/banks/' . urlencode($rec['image']),
                    ];
                }
            }

            $response = [
                'success' => true,
                'data' => array_values($uniqueAccounts)
            ];
        } else {
            $response = [
                'success' => false,
                'message' => 'No recent recipients found.'
            ];
        }
        
        echo json_encode($response);
} else {
    $response = [
        'success' => false,
        'message' => 'No recent recipients found.'
    ];
}

?>