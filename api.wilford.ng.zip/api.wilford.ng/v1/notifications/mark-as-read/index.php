<?php
require '../../../config/database.php';
require '../../headers/post_with_auth.php';

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
// file_put_contents("webhook_log.txt", "\nWebhook hit at: " . date("Y-m-d H:i:s") . "\nAuthorization: " . $authHeader . "\n", FILE_APPEND);

// Get raw input once
$rawData = file_get_contents("php://input");
$data = json_decode($rawData, true);

// Validate Authorization header
if (!$authHeader) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Authorization header missing.',
        'data' => []
    ]);
    exit;
}

list($type, $token) = explode(' ', $authHeader, 2);
if (strcasecmp($type, 'Bearer') !== 0 || empty($token)) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid token format.',
        'data' => []
    ]);
    exit;
}

// input data
$status = $data['status'];
$old_status = $data['oldStatus'];

// Authenticate user via token
$userStmt = $con->prepare("SELECT id FROM users WHERE token = ?");
$userStmt->bind_param("s", $token);
$userStmt->execute();
$userResult = $userStmt->get_result();

if ($userResult->num_rows === 0) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid token or user not found.',
        'data' => []
    ]);
    exit;
}

$userData = $userResult->fetch_assoc();
$userId = $userData['id'];

// Get all unique payment_ids for the user
$stmt = mysqli_prepare($con, "UPDATE notifications SET status = ? WHERE user_id = ? AND status = ?");
mysqli_stmt_bind_param($stmt, "iii", $status, $userId, $old_status);
mysqli_stmt_execute($stmt);

if (mysqli_stmt_affected_rows($stmt) > 0) {
     http_response_code(200);
    echo json_encode([
        'code' => '200',
        'status' => true,
        'message' => 'Successful.'
    ]);
} else {
    http_response_code(402);
    echo json_encode([
        'code' => '402',
        'status' => false,
        'message' => 'Failed.'
    ]); 
}

?>