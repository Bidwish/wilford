<?php
require '../../config/database.php';
require './../headers/get.php';

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
file_put_contents("webhook_log.txt", "\nWebhook hit at: " . date("Y-m-d H:i:s") . "\nAuthorization: " . $authHeader . "\n", FILE_APPEND);

// Validate Authorization header
if (!$authHeader) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Authorization header missing.',
        'data' => []
    ]);
    exit;
}

list($type, $token) = explode(' ', $authHeader, 2);
if (strcasecmp($type, 'Bearer') !== 0 || empty($token)) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid token format.',
        'data' => []
    ]);
    exit;
}

// Authenticate user via token
$userStmt = $con->prepare("SELECT id FROM users WHERE token = ?");
$userStmt->bind_param("s", $token);
$userStmt->execute();
$userResult = $userStmt->get_result();

if ($userResult->num_rows === 0) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid token or user not found.',
        'data' => []
    ]);
    exit;
}

$userData = $userResult->fetch_assoc();
$userId = $userData['id'];
file_put_contents("webhook_log.txt", "Authenticated User ID: $userId\n", FILE_APPEND);

$history = []; 

// Get all unique payment_ids for the user
$notificationStmt = $con->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC");
$notificationStmt->bind_param("i", $userId);
$notificationStmt->execute();
$notificationResult = $notificationStmt->get_result();

while ($notification = $notificationResult->fetch_assoc()) {
    $history[] = [
        'payment_id' => $notification['payment_id'],
        'senderName' => $notification['senderName'],
        'amount' => $notification['amount'],
        'status' => $notification['status'],
        'created_at' => $notification['created_at']
    ];
}

$response = [
    'success' => true,
    'message' => count($history) > 0 ? 'Payment history loaded.' : 'No payment history found.',
    'data' => $history
];

// Log full JSON response
file_put_contents("webhook_log.txt", "Response:\n" . json_encode($response, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);

header('Content-Type: application/json');
echo json_encode($response);

?>