<?php
include('./../../config/database.php');
include './../headers/get.php';

// Assume $con is already initialized (mysqli connection)
$history = [];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    // Validate token
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode(['status' => false, 'message' => 'Authorization header missing.']);
        exit;
    }

    list($type, $token) = explode(' ', $authHeader, 2);
    if (strcasecmp($type, 'Bearer') !== 0 || empty($token)) {
        http_response_code(401);
        echo json_encode(['status' => false, 'message' => 'Invalid token format.']);
        exit;
    }

    // Get request payload
    $rawData = file_get_contents("php://input");
    $body = json_decode($rawData, true);
    
    // Get the user data
    $stmt = mysqli_prepare($con, "SELECT id FROM users WHERE token = ?");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $userData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    $id = $userData['id'];
    
    $get = "SELECT * FROM payments WHERE user_id = '$id' OR rec_id = '$id' ORDER BY id ASC";
    $get_run = mysqli_query($con, $get);

    if ($get_run) {
        while ($historyData = mysqli_fetch_assoc($get_run)) {

        $history[] = [
            'payment_id' => $historyData['payment_id'],
            'user_id' => $historyData['user_id'],
            'rec_id' => $historyData['rec_id'],
            'senderAccNumber' => $historyData['senderAccNumber'],
            'senderAccName' => $historyData['senderAccName'],
            'senderBank' => $historyData['senderBank'],
            'recAccNumber' => $historyData['recAccNumber'],
            'recAccName' => $historyData['recAccName'],
            'recBank' => $historyData['recBank'],
            'amount' => $historyData['amount'],
            'method' => $historyData['method'],
            'remark' => $historyData['remark'],
            'status' => $historyData['status'],
            'phone' => $historyData['phone'],
            'email' => $historyData['email'],
            'network' => $historyData['network'],
            'dataName' => $historyData['dataName'],
            'mtNumber' => $historyData['mtNumber'],
            'provider' => $historyData['provider'],
            'accName' => $historyData['accName'],
            'serial' => $historyData['serial'],
            'pin' => $historyData['pin'],
            'pts' => $historyData['pts'],
            'fee' => $historyData['fee'],
            'transactionId' => $historyData['transactionId'],
            'requestId' => $historyData['requestId'],
            'created_at' => $historyData['created_at']
        ];
    }

    $response = [
        'success' => true,
        'data' => $history
    ];
} else {
    $response = [
        'success' => false,
        'message' => 'Failed to fetch data plans'
    ];
}

echo json_encode($response);

} else { 
    http_response_code(405); // Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>