<?php
include('../../../../config/database.php');
include '../../../headers/get.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    $chatId = $_GET['chatId'] ?? '';
    
    if (empty($chatId)) {
        http_response_code(400);
        echo json_encode([
            'success' => false, 
            'message' => 'Chat ID is required.'
        ]);
        exit;
    }

    $stmt = $con->prepare("SELECT user_id, message, created_at FROM live_support WHERE chat_id = ? ORDER BY created_at ASC");
    $stmt->bind_param("i", $chatId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $messages = [];
    
    while ($row = $result->fetch_assoc()) {
        $messages[] = [
            'sender' => $row['user_id'],
            'message' => $row['message'],
            'timestamp' => $row['created_at'],
        ];
    }
    
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => $messages
    ]);

} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>