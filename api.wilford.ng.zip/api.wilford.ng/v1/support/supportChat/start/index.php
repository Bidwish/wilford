<?php
include('../../../../config/database.php');
include '../../../headers/post_with_auth.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $authHeader . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    $stmt = mysqli_prepare($con, "SELECT id FROM users WHERE token = ?");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $userData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    $userId = $userData['id'];
            
    // Generate unique ticket ID
    $chat_id = rand(1000000, 9999999);

    $status = 'pending';

    // Check if the user already has an active ticket
    $check_query = $con->prepare("SELECT chat_id FROM live_chat WHERE user_id = ? AND status = 'pending'");
    $check_query->bind_param("i", $userId);
    $check_query->execute();
    $check_query->store_result();
    
    $stmt = $con->prepare("SELECT chat_id FROM live_chat WHERE user_id = ? AND status = 'pending'");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $chatData = $result->fetch_assoc();
        $chatId = $chatData['chat_id'];
        http_response_code(200);
        echo json_encode([
            'code' => '200',
            'status' => true,
            'message' => 'You already have an active Chat',
            'chatId' => $chatId
        ]); 
        exit();  
    }
    $check_query->close();

    // Prepare SQL query to insert a new ticket
    $ticket_query = $con->prepare("INSERT INTO live_chat (chat_id, user_id, status) VALUES (?, ?, ?)");
    $ticket_query->bind_param("sis", $chat_id, $userId, $status);

    // Execute query and handle file upload
    if ($ticket_query->execute()) {
        // Insert initial message into `live_support`
        $message = 'Hello; How can we help you?';
        $user = 'support';
        $t_query = $con->prepare("INSERT INTO live_support (chat_id, user_id, message) VALUES (?, ?, ?)");
        $t_query->bind_param("iss", $chat_id, $user, $message);

        if ($t_query->execute()) {
            http_response_code(200);
            echo json_encode([
                'code' => '200',
                'status' => true,
                'message' => 'Chat created successfully.',
                'chatId' => $chat_id
            ]); 
            exit();   // Success
        } else {
            http_response_code(500);
            echo json_encode([
                'code' => '500',
                'status' => false,
                'message' => 'Failed to insert into create chat'
            ]); 
            exit();
        }
        $t_query->close();
    } else {
        http_response_code(500);
        echo json_encode([
            'code' => '500',
            'status' => false,
            'message' => 'Failed to insert into create chat'
        ]); 
    }

    // Close the statement and connection
    $ticket_query->close();
    $con->close();
        
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>