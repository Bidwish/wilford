<?php
include('../../../config/database.php');
include './../../headers/get.php'; // (Set correct CORS headers for GET requests)

// Check request method
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    // $rawData = $authHeader;
    // $data = $authHeader;

    // Log for debugging (optional)
    // $logFile = "webhook_log.txt";
    // file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    // file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }

    // Lookup user by token (assuming token is email or any saved token)
    $stmt = $con->prepare("SELECT id FROM users WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
        $userId = $userData['id'];
        
        $query = "SELECT chat_id FROM live_chat WHERE user_id = '$userId' AND status != 'closed' ORDER BY id DESC ";
        $query_run = mysqli_query($con, $query);
        
        if ($query_run->num_rows > 0) { 
            $chatData = $query_run->fetch_assoc();
            $chatId = $chatData['chat_id'];
            http_response_code(200);
            echo json_encode([
                'status' => true,
                'chatId' => $chatId
            ]);
        } else {
            http_response_code(200);
        }
    } else {
        http_response_code(404);
        echo json_encode([
            'status' => false,
            'message' => 'Account not found.'
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
}
?>