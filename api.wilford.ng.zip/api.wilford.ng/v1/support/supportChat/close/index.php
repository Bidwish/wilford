<?php
include('../../../../config/database.php');
include '../../../headers/get.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $chatId = $_GET['chatId'];

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $chatId . "\n", FILE_APPEND);
    
    if (empty($chatId)) {
        echo "400"; // Missing ticket ID
        exit;
    }
    
    // Set the status
    $status = 'closed';

    // Prepare the SQL statement
    $ticket_query = $con->prepare("UPDATE live_chat SET status = ? WHERE chat_id = ?");
    // Bind parameters
    $ticket_query->bind_param("si", $status, $chatId);

    // Execute query and handle the response
    if ($ticket_query->execute()) {
        http_response_code(200); // Success
    } else {
        http_response_code(401); // Query execution failed
        echo json_encode([
            'status' => false,
            'message' => 'Something went worng, Please try again.'
        ]);
        exit();
    }
    // Close the statement
    $ticket_query->close();
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>