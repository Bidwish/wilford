<?php
include('../../../../config/database.php');
include '../../../headers/post.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    // $logFile = "webhook_log.txt";
    // file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    // file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);
    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }
    
    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }

    $chatId = $data['chatId'];
    $chat = $data['message'];
    
    $stmt = mysqli_prepare($con, "SELECT id FROM users WHERE token = ?");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $userData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    $userId = $userData['id'];
    
    // Prepare SQL query with prepared statements to prevent SQL injection
    $ticket_query = $con->prepare("INSERT INTO live_support (chat_id, user_id, message) VALUES (?, ?, ?)");
    $ticket_query->bind_param("iis", $chatId, $userId, $chat);

    // Execute query and handle file upload
    if ($ticket_query->execute()) {
        http_response_code(200);
    } else {
        http_response_code(401); // Query execution failed
        echo json_encode([
            'status' => false,
            'message' => 'Something went worng, Please try again.'
        ]);
        exit();
    }

    // Close the statement and connection
    $ticket_query->close();
    $con->close();
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>