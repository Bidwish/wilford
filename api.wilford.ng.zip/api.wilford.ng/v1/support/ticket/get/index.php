<?php
include('../../../../config/database.php');
include '../../../headers/get.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);
    
    $ticketlist = [];
    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    $stmt = mysqli_prepare($con, "SELECT id FROM users WHERE token = ?");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $userData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    $userId = $userData['id'];
    
    // Get All Ticket
    $query=mysqli_query($con, "SELECT * from tickets WHERE user_id='$userId'"); 
    $total=mysqli_num_rows ($query);
    
    // Get All Pending Ticket
    $query=mysqli_query($con, "SELECT * from tickets WHERE user_id='$userId' AND status='pending' "); 
    $pending=mysqli_num_rows ($query); 
    
    // Get All Processing Ticket
    $query=mysqli_query($con, "SELECT * from tickets WHERE user_id='$userId' AND status='processing' "); 
    $processing=mysqli_num_rows ($query);  
    
    // Get All Closed Ticket
    $query=mysqli_query($con, "SELECT * from tickets WHERE user_id='$userId' AND status='closed' "); 
    $closed=mysqli_num_rows ($query);  
    
    $get = "SELECT * FROM tickets WHERE user_id= ? ORDER BY `tickets`.`id` DESC";
    $stmt = $con->prepare($get);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $data = $stmt->get_result();
    
    // Check if any results exist
    if ($data->num_rows > 0) {
        // Fetch and display all user names
        while ($item = $data->fetch_assoc()) {
            $ticketlist[] = [
                'dateTime' => $item['created_at'],
                'ticketId' => $item['ticket_id'],
                'issueType' => $item['type'],
                'issueDescription' => $item['describes'],
                'status' => $item['status'],
                'pending' => $pending,
                'resolved' => $closed,
                'ongoing' => $processing,
                'total' => $total
            ];
        }
        
        $response = [
            'success' => true,
            'data' => $ticketlist
        ];
    } else {
       $response = [
            'success' => false,
            'message' => 'Failed to fetch Ticket'
        ];
    }
    echo json_encode($response);
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>