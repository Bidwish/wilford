<?php
include('../../../config/database.php');
include './../../headers/post_with_auth.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    
    if (!$authHeader) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Authorization header missing.'
        ]);
        exit;
    }

    // Split "Bearer <token>"
    list($type, $token) = explode(' ', $authHeader, 2);

    if (strcasecmp($type, 'Bearer') != 0 || empty($token)) {
        http_response_code(401);
        echo json_encode([
            'status' => false,
            'message' => 'Invalid token format.'
        ]);
        exit;
    }
    
    $type = $data['issue_type'];
    $trans_id = $data['transaction_id'];
    $describe = $data['issue_description'];
    
    $stmt = mysqli_prepare($con, "SELECT id FROM users WHERE token = ?");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $userData = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    $userId = $userData['id'];
    
    $check_query = "SELECT * FROM payments WHERE payment_id = ?";
    $stmt = $con->prepare($check_query);
    $stmt->bind_param("s", $trans_id);
    $stmt->execute();
    $check_run = $stmt->get_result();
    $rowCount = mysqli_num_rows($check_run);
    
    if ($rowCount < 1) {
        http_response_code(401);
        echo json_encode([
            'code' => '401',
            'status' => false,
            'message' => 'Transaction ID not found, Please try again.'
        ]); 
        exit();
    } else {
        // Generate unique ticket ID
        $ticket_id = rand(1000000, 9999999);
        // Ticket status
        $status = 'pending';
        // Prepare SQL query with prepared statements to prevent SQL injection
        $ticket_query = $con->prepare("INSERT INTO tickets (type, `describes`, ticket_id, trans_id, user_id, status) VALUES (?, ?, ?, ?, ?, ?)");
        $ticket_query->bind_param("ssisis", $type, $describe, $ticket_id, $trans_id, $userId, $status);
    
        // Execute query and handle file upload
        if ($ticket_query->execute()) {
            http_response_code(200);
            echo json_encode([
                'code' => '200',
                'status' => true,
                'message' => 'Ticket created successfully.'
            ]); 
            exit();    
        } else {
            http_response_code(400);
            echo json_encode([
                'code' => '400',
                'status' => false,
                'message' => 'An error occurred, Please try again.'
            ]); 
            exit();
        }   
        // Close the statement and connection
        $ticket_query->close();
        $con->close();  
    }
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>