<?php
include('../../../../config/database.php');
include '../../../headers/get.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'GET') {;
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND); 
    

    $ticketId = $_GET['ticketId'] ?? '';
    
    if (empty($ticketId)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Ticket ID is required.'
        ]);
        exit;
    }

    $stmt = $con->prepare("SELECT user_id, chat, created_at FROM ticket_chat WHERE ticket_id = ? ORDER BY created_at DESC");
    $stmt->bind_param("s", $ticketId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $messages = [];
    
    while ($row = $result->fetch_assoc()) {
        $messages[] = [
            'sender' => $row['user_id'],
            'message' => $row['chat'],
            'timestamp' => $row['created_at'],
        ];
    }
    
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => $messages
    ]);

} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>