<?php
include('../../../../config/database.php');
include '../../../headers/post.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the Authorization header
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    
    // Get raw input once
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    // Log for debugging (optional)
    $logFile = "webhook_log.txt";
    file_put_contents($logFile, "Webhook hit at: " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    file_put_contents($logFile, "Raw data: " . $rawData . "\n", FILE_APPEND);

    $ticket_id = $data['ticketId'];
    
    if (empty($ticket_id)) {
        echo "400"; // Missing ticket ID
        exit;
    }
    
    // Set the status
    $status = 'closed';

    // Prepare the SQL statement
    $ticket_query = $con->prepare("UPDATE tickets SET status = ? WHERE ticket_id = ?");
    // Bind parameters
    $ticket_query->bind_param("si", $status, $ticket_id);

    // Execute query and handle the response
    if ($ticket_query->execute()) {
        http_response_code(200); // Success
    } else {
        http_response_code(401); // Query execution failed
        echo json_encode([
            'status' => false,
            'message' => 'Something went worng, Please try again.'
        ]);
        exit();
    }
    // Close the statement
    $ticket_query->close();
} else {
    http_response_code(405); // 405 Method Not Allowed
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ]);
    exit();
}

?>